#!/usr/bin/env python3
"""
=====================================================================================
 DOE RUNNER for the MBR preliminary-design model (mbr_design.py)
-------------------------------------------------------------------------------------
 1. Builds a face-centred Central Composite Design (CCD, alpha = 1) in 5 factors:
        MLSS_gL     bioreactor MLSS               7 - 11  g/L
        Flux20_LMH  gross design flux @20 degC   20 - 30  L/m2.h
        SADm        membrane scour air demand   0.15 - 0.35 Nm3/m2.h
        Tmin_C      winter design temperature    10 - 16  degC   (noise / climate factor)
        SRTaer_d    aerobic SRT floor            12 - 20  d
    32 factorial + 10 axial + 6 centre points = 48 runs, randomised run order
    (identical structure to JMP: DOE > Classical > Response Surface Design > CCD-Uniform/Face).
 2. Runs the full engineering model at every point (biology, membranes, aeration,
    energy and the 240-day fouling simulation).
 3. Writes  mbr_doe_runs.csv        -> open in JMP
            MBR_RSM_analysis.jsl    -> JMP script: RSM fits, profiler, desirability
 4. Python cross-check of the same analysis (quadratic RSM by least squares, scaled
    effects, contours, Derringer desirability optimum verified with the full model).
 Run:  python doe_runner.py
=====================================================================================
"""
from __future__ import annotations

import csv
import itertools
import os
from dataclasses import asdict

import numpy as np
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

import mbr_design as M

OUT = "mbr_outputs"
os.makedirs(OUT, exist_ok=True)

FACTORS = {  # name: (low, high, unit, description)
    "MLSS_gL":    (7.0, 11.0, "g/L", "Bioreactor MLSS"),
    "Flux20_LMH": (20.0, 30.0, "L/m2.h", "Gross design flux at 20 C"),
    "SADm":       (0.15, 0.35, "Nm3/m2.h", "Specific membrane scour air"),
    "Tmin_C":     (10.0, 16.0, "C", "Winter design temperature"),
    "SRTaer_d":   (12.0, 20.0, "d", "Aerobic SRT floor"),
}
FNAMES = list(FACTORS)
RESPONSES = {  # name: (goal, unit, description)
    "Energy_kWh_m3":        ("min", "kWh/m3", "Specific energy demand"),
    "Footprint_m3":         ("min", "m3", "Bioreactor + membrane tank volume"),
    "Membrane_area_req_m2": ("min", "m2", "Required membrane area"),
    "Mean_TMP_bar":         ("min", "bar", "Mean TMP over 240 d"),
    "ProcessAir_Nm3h":      ("none", "Nm3/h", "Process air, summer max-day"),
    "Sludge_kgTSS_d":       ("none", "kg/d", "Waste sludge production"),
    "RC_per_year":          ("none", "1/yr", "Recovery cleans per year"),
}
DESIRABILITY = ["Energy_kWh_m3", "Footprint_m3", "Membrane_area_req_m2", "Mean_TMP_bar"]
T_DESIGN = 12.0  # climate factor held at the site's winter design value when optimising


# ----------------------------------------------------------------------------------
def ccd_face_centred(k: int, n_center: int = 6) -> np.ndarray:
    fact = np.array(list(itertools.product([-1, 1], repeat=k)), float)
    axial = np.vstack([s * np.eye(k)[i] for i in range(k) for s in (-1, 1)])
    return np.vstack([fact, axial, np.zeros((n_center, k))])


def decode(c: np.ndarray) -> dict:
    return {f: (lo + hi) / 2 + c[i] * (hi - lo) / 2 for i, (f, (lo, hi, *_)) in enumerate(FACTORS.items())}


def encode(x: dict) -> np.ndarray:
    return np.array([(x[f] - (lo + hi) / 2) / ((hi - lo) / 2) for f, (lo, hi, *_) in FACTORS.items()])


def run_model(x: dict, with_fouling: bool = True) -> dict:
    inf = M.Influent(T_min=x["Tmin_C"])
    d = M.DesignBasis(X_bio=x["MLSS_gL"], SRT_aer_floor=x["SRTaer_d"])
    k = M.Kinetics()
    J = x["Flux20_LMH"]
    m = M.MembraneSpec(J_avg20=J, J_mm20=1.2 * J, J_peak20=1.6 * J, SAD_m=x["SADm"])
    mem = M.membrane_design(inf, m)
    bio = M.biological_design(inf, d, k, mem)
    AOR = M.oxygen_demand(inf, k, bio)
    aer = M.aeration_design(inf, d, m, bio, mem, AOR)
    E = M.energy_balance(inf.Q_avg, aer["design_air_Nm3h"] / 1.25, mem["air_scour_Nm3h"], bio["V_anox"],
                         d.R_ras, bio["IR"], d.sub_diffuser, m.scour_sub, 0.75, 0.70, d.anox_mix_W_m3)
    out = {
        "Energy_kWh_m3": E["kWh_m3"]["TOTAL"],
        "Footprint_m3": bio["V_bio"] + mem["V_mt"],
        "Membrane_area_req_m2": mem["A_req"],
        "ProcessAir_Nm3h": aer["design_air_Nm3h"],
        "Sludge_kgTSS_d": bio["Px_TSS"],
    }
    if with_fouling:
        sim = M.fouling_simulation(inf, m, mem, X_mt=bio["X_mt"])
        n_rc = sum(1 for _, e in sim["events"] if e == "RC")
        out["Mean_TMP_bar"] = float(sim["TMP"].mean())
        out["RC_per_year"] = n_rc * 365 / 240
    return out


# ----------------------------------------------------------------------------------
# Quadratic response-surface model (same model JMP fits with '& RS' effects)
# ----------------------------------------------------------------------------------
TERMS = (["Intercept"] + FNAMES + [f"{a}*{b}" for a, b in itertools.combinations(FNAMES, 2)]
         + [f"{a}*{a}" for a in FNAMES])


def model_matrix(C: np.ndarray) -> np.ndarray:
    cols = [np.ones(len(C))] + [C[:, i] for i in range(5)]
    cols += [C[:, i] * C[:, j] for i, j in itertools.combinations(range(5), 2)]
    cols += [C[:, i] ** 2 for i in range(5)]
    return np.column_stack(cols)


def fit_rsm(C, y):
    X = model_matrix(C)
    beta, *_ = np.linalg.lstsq(X, y, rcond=None)
    yhat = X @ beta
    ss_res, ss_tot = np.sum((y - yhat) ** 2), np.sum((y - y.mean()) ** 2)
    n, p = X.shape
    r2 = 1 - ss_res / ss_tot
    return dict(beta=beta, r2=r2, r2adj=1 - (1 - r2) * (n - 1) / (n - p), rmse=np.sqrt(ss_res / (n - p)))


def desirability_min(y, lo, hi):
    return np.clip((hi - y) / (hi - lo), 0, 1)


# ----------------------------------------------------------------------------------
def write_jsl(limits: dict, fname: str):
    eff_main = ", ".join(f":{f} & RS" for f in FNAMES)
    eff_int = ", ".join(f":{a} * :{b}" for a, b in itertools.combinations(FNAMES, 2))
    eff_quad = ", ".join(f":{f} * :{f}" for f in FNAMES)
    coding = "\n".join(f'Column( dt, "{f}" ) << Set Property( "Coding", {{{lo}, {hi}}} );'
                       for f, (lo, hi, *_) in FACTORS.items())
    units = "\n".join(f'Column( dt, "{n}" ) << Set Property( "Units", "{u}" );'
                      for n, (_, u, _d) in RESPONSES.items())
    lims = "\n".join(
        f'Column( dt, "{r}" ) << Set Property( "Response Limits", {{Goal( Minimize ), '
        f'Lower( {lo:.6g}, 0.9819 ), Middle( {(lo+hi)/2:.6g}, 0.5 ), Upper( {hi:.6g}, 0.0183 ), Importance( 1 )}} );'
        for r, (lo, hi) in limits.items())
    ys = ", ".join(f'"{r}"' for r in RESPONSES)
    pred_cols = ", ".join(f':Name( "Pred Formula {r}" )' for r in DESIRABILITY)
    jsl = f"""// =====================================================================
// MBR_RSM_analysis.jsl
// Response-surface analysis of the MBR preliminary-design DOE
// (generated by doe_runner.py - 48-run face-centred CCD, 5 factors)
//
// HOW TO RUN: put this file and mbr_doe_runs.csv in the same folder,
// open this script in JMP (16 or later) and press Run Script (Ctrl+R).
// =====================================================================
Names Default To Here( 1 );

// ---- 1. Open the DOE table (same folder as script; otherwise ask) ----
dt = Try(
	Open( "mbr_doe_runs.csv" ),
	Open( Pick File( "Select mbr_doe_runs.csv", "", {{"CSV Files|csv", "All Files|*"}} ) )
);
dt << Set Name( "MBR DOE - face-centred CCD" );

// ---- 2. Factor coding (coefficients in coded -1..+1 units) ----------
{coding}

// ---- 3. Units and desirability limits (smaller-is-better) -----------
{units}
{lims}

// ---- 4. Quadratic response-surface model for every response ---------
ys = {{{ys}}};
fits = {{}};
For( i = 1, i <= N Items( ys ), i++,
	f = Eval(
		Substitute(
				Expr(
					dt << Fit Model(
						Y( _Y_ ),
						Effects( {eff_main},
							{eff_int},
							{eff_quad} ),
						Personality( "Standard Least Squares" ),
						Emphasis( "Effect Screening" ),
						Run()
					)
				),
			Expr( _Y_ ), Parse( ":" || ys[i] )
		)
	);
	f << Prediction Formula;          // saves "Pred Formula <response>"
	Insert Into( fits, f );
	// carry desirability limits over to the saved formula column
	lim = Column( dt, ys[i] ) << Get Property( "Response Limits" );
	If( !Is Empty( lim ),
		pc = Column( dt, "Pred Formula " || ys[i] );
		Eval( Eval Expr( pc << Set Property( "Response Limits", Expr( lim ) ) ) );
	);
);

// ---- 5. Prediction profiler + desirability optimisation -------------
//      Winter temperature is a climate (noise) factor: locked at {T_DESIGN:g} C,
//      the other four factors are optimised.
prof = dt << Profiler(
	Y( {pred_cols} ),
	Desirability Functions( 1 ),
	Term Value( Tmin_C( {T_DESIGN:g}, Lock( 1 ), Show( 1 ) ) )
);
prof << Maximize Desirability;

// ---- 6. Contour profiler: energy vs fouling trade-off --------------
dt << Contour Profiler(
	Y( :Name( "Pred Formula Energy_kWh_m3" ), :Name( "Pred Formula Mean_TMP_bar" ),
		:Name( "Pred Formula Footprint_m3" ) ),
	Surface Plot( 1 )
);

// ---- 7. Raw-data overview ------------------------------------------
dt << Graph Builder(
	Size( 640, 420 ),
	Variables( X( :MLSS_gL ), Y( :Energy_kWh_m3 ), Overlay( :SADm ) ),
	Elements( Points( X, Y, Legend( 1 ) ), Smoother( X, Y, Legend( 2 ) ) )
);
"""
    with open(fname, "w") as fh:
        fh.write(jsl)


# ----------------------------------------------------------------------------------
def main():
    rng = np.random.default_rng(2026)
    C = ccd_face_centred(5, n_center=6)
    order = rng.permutation(len(C))
    rows = []
    for run_no, idx in enumerate(order, 1):
        c = C[idx]
        x = decode(c)
        pattern = "".join("0" if v == 0 else ("+" if v > 0 else "-") for v in c)
        if pattern == "00000":
            pattern = "0"
        elif np.count_nonzero(c) == 1:
            pattern = "".join("A" if v > 0 else ("a" if v < 0 else "0") for v in c)
        rows.append({"Run": run_no, "Pattern": pattern, **{f: round(x[f], 4) for f in FNAMES},
                     **run_model(x)})
        print(f"run {run_no:2d}/{len(C)}  {pattern:6s}  E={rows[-1]['Energy_kWh_m3']:.3f}  "
              f"TMP={rows[-1]['Mean_TMP_bar']:.3f}")

    with open(f"{OUT}/mbr_doe_runs.csv", "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=list(rows[0]))
        w.writeheader()
        for r in rows:
            w.writerow({k: (round(v, 5) if isinstance(v, float) else v) for k, v in r.items()})

    Cc = np.array([encode(r) for r in rows])
    Y = {r: np.array([row[r] for row in rows]) for r in RESPONSES}
    limits = {r: (float(Y[r].min()), float(Y[r].max())) for r in DESIRABILITY}
    write_jsl(limits, f"{OUT}/MBR_RSM_analysis.jsl")

    # ---------------- Python cross-check of the JMP analysis -------------------
    fits = {r: fit_rsm(Cc, Y[r]) for r in RESPONSES}

    # (a) scaled effects (coded coefficients) - equivalent of JMP 'Scaled Estimates'
    fig, axs = plt.subplots(2, 2, figsize=(15, 10))
    for ax, r in zip(axs.flat, DESIRABILITY):
        b = fits[r]["beta"][1:]
        o = np.argsort(np.abs(b))[::-1][:10][::-1]
        names = np.array(TERMS[1:])[o]
        ax.barh(names, b[o], color=["#c0392b" if v > 0 else "#1f4e79" for v in b[o]])
        ax.axvline(0, color="k", lw=.8)
        ax.set_title(f"{r}   (R² = {fits[r]['r2']:.4f}, R²adj = {fits[r]['r2adj']:.4f})", fontsize=10)
        ax.set_xlabel(f"Scaled estimate ({RESPONSES[r][1]} per coded unit)")
        ax.grid(axis="x", alpha=.3)
    fig.suptitle("Quadratic RSM - ten largest scaled effects per response (red = increases response)",
                 weight="bold")
    fig.tight_layout(); fig.savefig(f"{OUT}/06_doe_scaled_effects.png", dpi=150); plt.close(fig)

    # (b) desirability optimum (Tmin locked at design value) on fitted surfaces
    n = 200_000
    S = rng.uniform(-1, 1, (n, 5))
    S[:, FNAMES.index("Tmin_C")] = encode({**{f: (FACTORS[f][0] + FACTORS[f][1]) / 2 for f in FNAMES},
                                           "Tmin_C": T_DESIGN})[FNAMES.index("Tmin_C")]
    Xs = model_matrix(S)
    D = np.ones(n)
    for r in DESIRABILITY:
        D *= desirability_min(Xs @ fits[r]["beta"], *limits[r])
    D = D ** (1 / len(DESIRABILITY))
    best = S[np.argmax(D)]
    x_opt = decode(best)
    pred = {r: float(model_matrix(best[None])[0] @ fits[r]["beta"]) for r in RESPONSES}
    actual = run_model(x_opt)
    base = run_model({f: v for f, v in zip(FNAMES, [9.0, 25.0, 0.25, 12.0, 15.0])})

    # (c) contour plots of fitted surfaces vs MLSS & flux (SAD_m, SRT at optimum, T = 12)
    g = np.linspace(-1, 1, 81)
    G1, G2 = np.meshgrid(g, g)
    grid = np.tile(best, (G1.size, 1))
    grid[:, 0], grid[:, 1] = G1.ravel(), G2.ravel()
    Xg = model_matrix(grid)
    mx = FACTORS["MLSS_gL"][0] + (g + 1) / 2 * (FACTORS["MLSS_gL"][1] - FACTORS["MLSS_gL"][0])
    fx = FACTORS["Flux20_LMH"][0] + (g + 1) / 2 * (FACTORS["Flux20_LMH"][1] - FACTORS["Flux20_LMH"][0])
    fig, axs = plt.subplots(2, 2, figsize=(14, 11))
    Dg = np.ones(G1.size)
    for ax, r, cm in zip(axs.flat[:3], ["Energy_kWh_m3", "Mean_TMP_bar", "Footprint_m3"],
                         ["YlOrRd", "PuRd", "Blues"]):
        Z = (Xg @ fits[r]["beta"]).reshape(G1.shape)
        cf = ax.contourf(mx, fx, Z, 18, cmap=cm)
        cs = ax.contour(mx, fx, Z, 9, colors="k", linewidths=.5); ax.clabel(cs, fontsize=7, fmt="%.3g")
        fig.colorbar(cf, ax=ax, label=RESPONSES[r][1])
        ax.plot(x_opt["MLSS_gL"], x_opt["Flux20_LMH"], "*", ms=18, mec="k", mfc="gold")
        ax.set_title(r); ax.set_xlabel("MLSS (g/L)"); ax.set_ylabel("Flux @20°C (L/m²·h)")
    for r in DESIRABILITY:
        Dg *= desirability_min(Xg @ fits[r]["beta"], *limits[r])
    Dg = (Dg ** (1 / len(DESIRABILITY))).reshape(G1.shape)
    cf = axs[1, 1].contourf(mx, fx, Dg, 18, cmap="viridis")
    fig.colorbar(cf, ax=axs[1, 1], label="overall desirability D")
    axs[1, 1].plot(x_opt["MLSS_gL"], x_opt["Flux20_LMH"], "*", ms=18, mec="k", mfc="gold")
    axs[1, 1].set_title("Overall desirability (energy, footprint, area, TMP)")
    axs[1, 1].set_xlabel("MLSS (g/L)"); axs[1, 1].set_ylabel("Flux @20°C (L/m²·h)")
    fig.suptitle(f"Fitted response surfaces at SAD_m = {x_opt['SADm']:.3f}, SRT_aer = {x_opt['SRTaer_d']:.1f} d, "
                 f"T = {T_DESIGN:g} °C   (★ = desirability optimum)", weight="bold")
    fig.tight_layout(); fig.savefig(f"{OUT}/07_rsm_contours.png", dpi=150); plt.close(fig)

    # (d) prediction-profiler style traces around the optimum
    fig, axs = plt.subplots(len(DESIRABILITY), 5, figsize=(17, 11), sharex="col")
    for j, f in enumerate(FNAMES):
        sweep = np.tile(best, (61, 1)); sweep[:, j] = np.linspace(-1, 1, 61)
        xs = FACTORS[f][0] + (sweep[:, j] + 1) / 2 * (FACTORS[f][1] - FACTORS[f][0])
        for i, r in enumerate(DESIRABILITY):
            ax = axs[i, j]
            ax.plot(xs, model_matrix(sweep) @ fits[r]["beta"], color="#1f4e79", lw=2)
            ax.axvline(x_opt[f], color="#c0392b", ls="--", lw=1)
            ax.grid(alpha=.3)
            if j == 0: ax.set_ylabel(r.replace("_", "\n", 1), fontsize=9)
            if i == len(DESIRABILITY) - 1: ax.set_xlabel(f"{f}\n= {x_opt[f]:.3g}", fontsize=9)
    fig.suptitle("Prediction profiler (Python equivalent of the JMP Profiler) at the desirability optimum",
                 weight="bold")
    fig.tight_layout(); fig.savefig(f"{OUT}/08_prediction_profiler.png", dpi=150); plt.close(fig)

    # ---------------- summary -------------------------------------------------
    lines = ["# DOE / response-surface results (Python cross-check of the JMP analysis)\n",
             f"Design: face-centred CCD, 5 factors, {len(rows)} runs (32 factorial + 10 axial + 6 centre).\n",
             "## Model fit (full quadratic, 21 terms)",
             "| Response | R² | R² adj | RMSE |", "|---|---|---|---|"]
    lines += [f"| {r} | {fits[r]['r2']:.4f} | {fits[r]['r2adj']:.4f} | {fits[r]['rmse']:.4g} |" for r in RESPONSES]
    lines += ["\n## Desirability optimum (Tmin locked at 12 °C)",
              f"Overall desirability D = {D.max():.3f}\n",
              "| Factor | Optimum | Baseline design |", "|---|---|---|"]
    lines += [f"| {f} | {x_opt[f]:.3g} | {v} |" for f, v in zip(FNAMES, [9.0, 25.0, 0.25, 12.0, 15.0])]
    lines += ["\n| Response | RSM prediction | Full model at optimum | Baseline design |", "|---|---|---|---|"]
    lines += [f"| {r} | {pred[r]:.4g} | {actual[r]:.4g} | {base[r]:.4g} |" for r in RESPONSES]
    with open(f"{OUT}/doe_summary.md", "w") as fh:
        fh.write("\n".join(lines))
    print("\n".join(lines))


if __name__ == "__main__":
    main()
