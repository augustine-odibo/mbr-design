#!/usr/bin/env python3
"""
=====================================================================================
 MEMBRANE BIOREACTOR (MBR) - PRELIMINARY DESIGN, DIAGRAMS & SCALE-UP MODEL
 Application: modernization of an existing conventional activated sludge (CAS) plant
              by inserting an MLE-type MBR treatment sequence:
              coarse screen -> grit/grease -> fine screen (<=1 mm) -> anoxic -> aerobic
              -> submerged hollow-fibre membrane tank -> permeate -> UV
=====================================================================================
 Methods / references used (standard design literature):
   * Metcalf & Eddy (2014) Wastewater Engineering, 5th ed. - activated sludge kinetics,
     biomass production, oxygen demand, MLE nitrogen removal, blower power.
   * Judd, S. (2011) The MBR Book, 2nd ed. - flux, SAD_m / SAD_p, cleaning regimes,
     specific energy demand benchmarks.
   * Krampe & Krauth (2003) - alpha factor vs MLSS: alpha = exp(-0.08788 * MLSS[g/L]).
   * Resistance-in-series filtration law: TMP = mu(T) * J * (Rm + Rres + Rirr).
 All numbers are preliminary-design values; site data (influent characterisation,
 vendor membrane data, pilot results) must replace defaults before detailed design.

 Run:  python mbr_design.py            -> writes figures + report into ./mbr_outputs
 Requires: numpy, matplotlib
=====================================================================================
"""
from __future__ import annotations

import json
import math
import os
from dataclasses import dataclass, asdict, field

import numpy as np
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, Rectangle, Circle

OUT = "mbr_outputs"
os.makedirs(OUT, exist_ok=True)

RHO_W = 998.0          # kg/m3
G = 9.81               # m/s2
P_ATM = 101.325        # kPa
O2_PER_NM3_AIR = 0.300 # kg O2 per Nm3 air (1.293 kg/Nm3 * 0.232)


# ----------------------------------------------------------------------------------
# 1. INPUT DATA
# ----------------------------------------------------------------------------------
@dataclass
class Influent:
    """Raw municipal wastewater after coarse screening (no primary settling)."""
    Q_avg: float = 12_000.0     # m3/d  average dry-weather flow
    pf_maxmonth: float = 1.30   # peaking factors
    pf_maxday: float = 1.60
    pf_peakhour: float = 2.00   # peak hour that membranes must pass (after EQ if any)
    BOD: float = 280.0          # g/m3
    COD: float = 600.0
    bCOD_BOD: float = 1.60      # biodegradable COD / BOD5
    TSS: float = 300.0
    VSS: float = 240.0
    nbVSS_frac: float = 0.35    # non-biodegradable fraction of VSS
    TKN: float = 60.0           # g N/m3
    NH4: float = 40.0
    TP: float = 9.0             # g P/m3
    Alk: float = 300.0          # g CaCO3/m3
    T_min: float = 12.0         # degC, winter design (nitrification, flux)
    T_max: float = 24.0         # degC, summer design (oxygen)


@dataclass
class DesignBasis:
    NH4_eff: float = 1.0        # g/m3
    TN_eff: float = 10.0
    orgN_eff: float = 1.0
    TP_eff: float = 0.5
    DO_aer: float = 2.0         # g/m3 in aerobic zone
    DO_mlr: float = 1.0         # DO carried with mixed-liquor recycle to anoxic
    SF_nit: float = 1.5         # safety factor on nitrification SRT
    SRT_aer_floor: float = 15.0 # d - MBR practice (sludge stability, fouling control)
    X_bio: float = 9.0          # kg TSS/m3 in anoxic/aerobic tanks
    R_ras: float = 4.0          # membrane tank -> aerobic recycle ratio (Q multiples)
    swd_bio: float = 5.5        # m side water depth (existing CAS tanks)
    sub_diffuser: float = 5.2   # m diffuser submergence
    sote_per_m: float = 0.055   # fine-bubble clean-water SOTE per m submergence
    fouling_F: float = 0.90     # diffuser fouling factor
    beta: float = 0.95
    elev_m: float = 120.0       # site elevation (Radnor-type site), m a.s.l.
    Fe_P_molar: float = 1.8     # FeCl3 simultaneous precipitation
    anox_mix_W_m3: float = 5.0  # submersible mixer power density


@dataclass
class Kinetics:
    """Metcalf & Eddy (2014) Table 8-14 / 8-24 default values at 20 degC."""
    mu_H: float = 6.0;   th_muH: float = 1.07
    Ks: float = 8.0
    Y_H: float = 0.45
    b_H: float = 0.12;   th_bH: float = 1.04
    fd: float = 0.15
    mu_A: float = 0.90;  th_muA: float = 1.072
    Kn: float = 0.50
    Ko_A: float = 0.50
    Y_A: float = 0.15
    b_A: float = 0.17;   th_bA: float = 1.029
    SDNR20: float = 0.08; th_SDNR: float = 1.026   # g NO3-N / g MLVSS.d
    N_in_biomass: float = 0.12  # g N / g VSS
    P_in_biomass: float = 0.015


@dataclass
class MembraneSpec:
    """Generic reinforced PVDF hollow-fibre (0.04-0.1 um) submerged module data."""
    module_area: float = 34.4        # m2 per module
    modules_per_cassette: int = 48
    cassette_L: float = 1.9          # m
    cassette_W: float = 2.2
    cassette_H: float = 2.6
    J_avg20: float = 25.0            # L/m2.h gross design flux, 20 degC
    J_mm20: float = 30.0             # L/m2.h sustained max-month flux, 20 degC
    J_peak20: float = 40.0           # L/m2.h short-term peak flux, 20 degC
    t_filt: float = 9.0              # min filtration
    t_relax: float = 1.0             # min relaxation (air scour continues)
    mc_downtime: float = 0.006       # fraction of time in maintenance cleaning
    n_trains: int = 4
    Lp_clean20: float = 400.0        # L/m2.h.bar clean-membrane permeability
    SAD_m: float = 0.25              # Nm3 air / m2 membrane . h
    mt_depth: float = 3.4            # m membrane tank water depth
    scour_sub: float = 3.0           # m scour aerator submergence
    scour_sote_per_m: float = 0.012  # coarse-bubble SOTE per m
    TMP_max: float = 0.30            # bar - recovery-clean trigger


@dataclass
class ExistingCAS:
    """Plant being modernised (illustrative)."""
    n_aer_tanks: int = 2
    V_aer_each: float = 4_000.0      # m3
    X_cas: float = 3.5               # kg/m3 limited by secondary clarifier SLR
    n_clarifiers: int = 2
    clarifier_D: float = 28.0        # m
    clarifier_swd: float = 4.0


# ----------------------------------------------------------------------------------
# 2. PROPERTY CORRELATIONS
# ----------------------------------------------------------------------------------
def water_viscosity(T: float) -> float:
    """Dynamic viscosity of water, Pa.s (Vogel-type correlation)."""
    return 2.414e-5 * 10 ** (247.8 / (T + 133.15))


def arr(k20: float, theta: float, T: float) -> float:
    return k20 * theta ** (T - 20.0)


def do_saturation(T: float) -> float:
    """Clean-water DO saturation at 1 atm, g/m3 (APHA polynomial)."""
    return 14.652 - 0.41022 * T + 0.007991 * T**2 - 0.000077774 * T**3


def alpha_factor(mlss_gL: float) -> float:
    """Krampe & Krauth (2003) - oxygen transfer alpha factor vs MLSS."""
    return math.exp(-0.08788 * mlss_gL)


def pressure_at_elev(elev: float) -> float:
    return P_ATM * (1 - 2.25577e-5 * elev) ** 5.25588  # kPa


# ----------------------------------------------------------------------------------
# 3. MEMBRANE SIZING
# ----------------------------------------------------------------------------------
def membrane_design(inf: Influent, m: MembraneSpec) -> dict:
    mu_ratio = water_viscosity(20) / water_viscosity(inf.T_min)  # flux temperature corr.
    avail = m.t_filt / (m.t_filt + m.t_relax) * (1 - m.mc_downtime)

    J_avg_T = m.J_avg20 * mu_ratio
    J_peak_T = m.J_peak20 * mu_ratio
    Jnet_avg = J_avg_T * avail
    Jnet_peak = J_peak_T * avail

    Q_avg_h = inf.Q_avg / 24.0                       # m3/h
    Q_mm_h = Q_avg_h * inf.pf_maxmonth
    Q_ph_h = Q_avg_h * inf.pf_peakhour

    Jnet_mm = m.J_mm20 * mu_ratio * avail
    # Case A: average flow with one train offline for recovery cleaning (N-1)
    A_avg = Q_avg_h * 1000 / Jnet_avg / ((m.n_trains - 1) / m.n_trains)
    # Case B: max-month flow, all trains, sustained flux
    A_mm = Q_mm_h * 1000 / Jnet_mm
    # Case C: peak-hour flow, all trains online, short-term peak flux
    A_ph = Q_ph_h * 1000 / Jnet_peak
    cases = {"average flow, N-1 trains": A_avg, "max-month flow, sustained flux": A_mm,
             "peak-hour flow, peak flux": A_ph}
    governing = max(cases, key=cases.get)
    A_req = cases[governing]

    A_cas = m.module_area * m.modules_per_cassette
    n_cas_train = math.ceil(A_req / A_cas / m.n_trains)
    n_cas = n_cas_train * m.n_trains
    A_inst = n_cas * A_cas

    # Membrane tank geometry per train (0.3 m clearances)
    L_train = n_cas_train * (m.cassette_L + 0.30) + 1.0
    W_train = m.cassette_W + 2 * 0.30
    V_train = L_train * W_train * m.mt_depth
    V_mt = V_train * m.n_trains

    air_scour = A_inst * m.SAD_m                       # Nm3/h
    Jop_avg = Q_avg_h * 1000 / (A_inst * avail)        # actual gross flux at Q_avg
    SAD_p = air_scour / Q_avg_h                        # Nm3 air / m3 permeate
    packing = A_inst / V_mt                            # m2/m3

    return dict(mu_ratio=mu_ratio, availability=avail, J_avg_T=J_avg_T, J_peak_T=J_peak_T,
                Jnet_avg=Jnet_avg, Jnet_peak=Jnet_peak, A_avg=A_avg, A_mm=A_mm, A_ph=A_ph, A_req=A_req,
                governing=governing, A_cassette=A_cas, n_cas_train=n_cas_train, n_cassettes=n_cas,
                n_modules=n_cas * m.modules_per_cassette, A_installed=A_inst,
                L_train=L_train, W_train=W_train, V_mt=V_mt, air_scour_Nm3h=air_scour,
                J_operating_avg=Jop_avg, SAD_p=SAD_p, packing_density=packing)


# ----------------------------------------------------------------------------------
# 4. BIOLOGICAL DESIGN (MLE configuration, iterative anoxic fraction)
# ----------------------------------------------------------------------------------
def nitrification_srt(k: Kinetics, d: DesignBasis, T: float) -> float:
    mu = arr(k.mu_A, k.th_muA, T) * d.NH4_eff / (k.Kn + d.NH4_eff) * d.DO_aer / (k.Ko_A + d.DO_aer)
    b = arr(k.b_A, k.th_bA, T)
    return 1.0 / (mu - b)


def biological_design(inf: Influent, d: DesignBasis, k: Kinetics, mem: dict) -> dict:
    T = inf.T_min
    Q = inf.Q_avg
    bCOD = inf.bCOD_BOD * inf.BOD
    nbVSS = inf.nbVSS_frac * inf.VSS
    iTSS = inf.TSS - inf.VSS

    SRTmin = nitrification_srt(k, d, T)
    SRT_aer = max(d.SF_nit * SRTmin, d.SRT_aer_floor)

    muH, bH = arr(k.mu_H, k.th_muH, T), arr(k.b_H, k.th_bH, T)
    muA, bA = arr(k.mu_A, k.th_muA, T), arr(k.b_A, k.th_bA, T)
    X_mt = d.X_bio * (1 + d.R_ras) / d.R_ras           # membrane-tank MLSS (mass balance)

    f_anox, NOx = 0.20, 0.8 * inf.TKN
    for _ in range(50):
        SRT = SRT_aer / (1 - f_anox)
        S = k.Ks * (1 + bH * SRT) / (SRT * (muH - bH) - 1)            # effluent bCOD
        Px_H = Q * k.Y_H * (bCOD - S) / (1 + bH * SRT) / 1000          # kg VSS/d
        Px_D = k.fd * bH * Px_H * SRT
        Px_A = Q * k.Y_A * NOx / (1 + bA * SRT) / 1000
        Px_bio = Px_H + Px_D + Px_A
        NOx = inf.TKN - d.NH4_eff - d.orgN_eff - k.N_in_biomass * Px_bio * 1000 / Q

        # phosphorus: biological uptake + FeCl3 simultaneous precipitation
        P_bio = k.P_in_biomass * Px_bio * 1000 / Q
        P_chem = max(inf.TP - P_bio - d.TP_eff, 0)
        Fe_kgd = Q * P_chem / 30.97 * d.Fe_P_molar * 55.85 / 1000
        chem_sludge = Fe_kgd * 3.6                                      # FePO4 + Fe(OH)3

        Px_VSS = Px_bio + Q * nbVSS / 1000
        Px_TSS = Px_bio / 0.85 + Q * nbVSS / 1000 + Q * iTSS / 1000 + chem_sludge
        M_total = Px_TSS * SRT                                          # kg TSS inventory

        # MLE nitrate balance
        NO3_eff = d.TN_eff - d.NH4_eff - d.orgN_eff
        IR = max(NOx / NO3_eff - 1.0, 0.0)                              # total recycle to anoxic
        NO3_rem = Q * (NOx - NO3_eff) / 1000                            # kg N/d
        DO_eq = IR * Q * d.DO_mlr / 2.86 / 1000                         # kg NO3-N eq/d
        vss_frac = Px_VSS / Px_TSS
        SDNR = arr(k.SDNR20, k.th_SDNR, T)
        V_anox = (NO3_rem + DO_eq) / (SDNR * d.X_bio * vss_frac)

        M_mt = mem["V_mt"] * X_mt
        V_aer = max((M_total - M_mt) / d.X_bio - V_anox, 0.0)
        f_new = V_anox * d.X_bio / M_total
        if abs(f_new - f_anox) < 1e-6:
            break
        f_anox = 0.5 * f_anox + 0.5 * f_new

    V_bio = V_anox + V_aer
    HRT = (V_bio + mem["V_mt"]) / Q * 24
    FM = Q * inf.BOD / 1000 / (M_total * vss_frac)
    Y_obs = Px_TSS / (Q * (inf.BOD) / 1000)

    # Alkalinity check
    N_nit = NOx
    alk_eff = inf.Alk - 7.14 * N_nit + 3.57 * (NOx - NO3_eff) - 2.0 * Fe_kgd * 1000 / Q
    alk_add = max(80 - alk_eff, 0) * Q / 1000                          # kg CaCO3/d

    return dict(T_design=T, SRT_nit_min=SRTmin, SRT_aer=SRT_aer, SRT_total=SRT, S_eff_bCOD=S,
                Px_H=Px_H, Px_D=Px_D, Px_A=Px_A, Px_bio=Px_bio, Px_VSS=Px_VSS, Px_TSS=Px_TSS,
                chem_sludge=chem_sludge, Fe_kgd=Fe_kgd, NOx=NOx, NO3_eff=NO3_eff, IR=IR,
                NO3_removed=NO3_rem, SDNR_T=SDNR, V_anox=V_anox, V_aer=V_aer, V_bio=V_bio,
                f_anox=f_anox, X_mt=X_mt, M_total=M_total, HRT_h=HRT, FM=FM, Y_obs=Y_obs,
                VSS_TSS=vss_frac, alk_eff=alk_eff, alk_add_kgd=alk_add)


# ----------------------------------------------------------------------------------
# 5. OXYGEN DEMAND & AERATION
# ----------------------------------------------------------------------------------
def oxygen_demand(inf: Influent, k: Kinetics, bio: dict) -> float:
    """Average-day actual oxygen requirement AOR, kg O2/d (M&E Eq. 8-17 + denit credit)."""
    bCOD = inf.bCOD_BOD * inf.BOD
    Ro = (inf.Q_avg * (bCOD - bio["S_eff_bCOD"]) / 1000 - 1.42 * bio["Px_bio"]
          + 4.57 * inf.Q_avg * bio["NOx"] / 1000 - 2.86 * bio["NO3_removed"])
    return Ro


def aeration_design(inf: Influent, d: DesignBasis, m: MembraneSpec, bio: dict, mem: dict,
                    AOR_avg: float, sub: float | None = None, sote_per_m: float | None = None) -> dict:
    sub = d.sub_diffuser if sub is None else sub
    sote_pm = d.sote_per_m if sote_per_m is None else sote_per_m
    Pb = pressure_at_elev(d.elev_m)
    res = {}
    for case, T, pf in (("winter", inf.T_min, 1.0), ("summer", inf.T_max, 1.0),
                        ("summer max-day", inf.T_max, 1.25)):
        Cs20 = do_saturation(20)
        CsT = do_saturation(T) * Pb / P_ATM
        Pd = Pb + RHO_W * G * sub / 1000
        CsTH = CsT * 0.5 * (Pd / Pb + 19.0 / 21.0)                    # mid-depth saturation
        alpha = alpha_factor(d.X_bio)
        AOR = AOR_avg * pf
        # O2 delivered by membrane scour air (coarse bubble, in membrane tank)
        alpha_mt = alpha_factor(bio["X_mt"])
        sote_sc = m.scour_sote_per_m * m.scour_sub
        CsTH_mt = CsT * 0.5 * ((Pb + RHO_W * G * m.scour_sub / 1000) / Pb + 19.0 / 21.0)
        f_mt = alpha_mt * (d.beta * CsTH_mt - 4.0) / Cs20 * 1.024 ** (T - 20)
        AOTR_scour = mem["air_scour_Nm3h"] * 24 * O2_PER_NM3_AIR * sote_sc * f_mt
        AOR_proc = max(AOR - AOTR_scour, 0)
        f_proc = alpha * d.fouling_F * (d.beta * CsTH - d.DO_aer) / Cs20 * 1.024 ** (T - 20)
        SOTR = AOR_proc / f_proc
        SOTE = sote_pm * sub
        air = SOTR / (O2_PER_NM3_AIR * SOTE) / 24                      # Nm3/h
        res[case] = dict(T=T, alpha=alpha, AOR=AOR, AOTR_scour=AOTR_scour, SOTR=SOTR,
                         SOTE=SOTE, air_Nm3h=air, AOR_SOR=f_proc)
    res["design_air_Nm3h"] = max(v["air_Nm3h"] for v in res.values() if isinstance(v, dict))
    return res


def blower_kW(air_Nm3h: float, submergence: float, losses_kPa: float, eff: float,
              T_in_C: float = 25.0, elev: float = 120.0) -> float:
    """Adiabatic blower power, M&E Eq. 5-56 (SI)."""
    w = air_Nm3h * 1.293 / 3600.0                                     # kg/s
    p1 = pressure_at_elev(elev)
    p2 = p1 + RHO_W * G * submergence / 1000 + losses_kPa
    return w * 8.314 * (T_in_C + 273.15) / (29.7 * 0.283 * eff) * ((p2 / p1) ** 0.283 - 1)


def pump_kW(Q_m3d: float, H: float, eff: float) -> float:
    return RHO_W * G * (Q_m3d / 86400) * H / eff / 1000


# ----------------------------------------------------------------------------------
# 6. ENERGY BALANCE (used for full scale and pilot scale)
# ----------------------------------------------------------------------------------
def energy_balance(Q: float, air_proc: float, air_scour: float, V_anox: float, R: float, IR: float,
                   sub_proc: float, sub_scour: float, blower_eff: float, pump_eff: float,
                   mix_W_m3: float, misc_kWh_m3: float = 0.04) -> dict:
    kw = dict(
        process_aeration=blower_kW(air_proc, sub_proc, 15.0, blower_eff),
        membrane_scour=blower_kW(air_scour, sub_scour, 10.0, blower_eff),
        permeate_pumping=pump_kW(Q, 6.0, pump_eff),
        RAS_pumping=pump_kW(R * Q, 1.5, pump_eff * 0.9),
        MLR_pumping=pump_kW(IR * Q, 0.8, pump_eff * 0.85),
        anoxic_mixing=V_anox * mix_W_m3 / 1000,
        screens_CIP_misc=misc_kWh_m3 * Q / 24,
    )
    kwh_m3 = {key: v * 24 / Q for key, v in kw.items()}
    kwh_m3["TOTAL"] = sum(kwh_m3.values())
    return dict(kW=kw, kWh_m3=kwh_m3)


# ----------------------------------------------------------------------------------
# 7. MEMBRANE FOULING / TMP SIMULATION (resistance in series, cleaning regime)
# ----------------------------------------------------------------------------------
def fouling_simulation(inf: Influent, m: MembraneSpec, mem: dict, days: int = 240, seed: int = 3,
                       X_mt: float = 11.25):
    rng = np.random.default_rng(seed)
    dt = 1.0                                                     # h
    n = int(days * 24 / dt)
    t = np.arange(n) * dt / 24.0
    T = 0.5 * (inf.T_min + inf.T_max) - 0.5 * (inf.T_max - inf.T_min) * np.cos(2 * np.pi * (t - 30) / 365)
    hour = (np.arange(n) * dt) % 24
    diurnal = 1 + 0.38 * np.sin(2 * np.pi * (hour - 9) / 24) + rng.normal(0, 0.05, n)
    storms = np.zeros(n)
    for d0 in rng.choice(np.arange(5, days - 2), size=6, replace=False):   # wet-weather events
        i0 = int(d0 * 24); storms[i0:i0 + 18] = 0.55
    Qh = inf.Q_avg / 24 * np.clip(diurnal + storms, 0.4, inf.pf_peakhour)

    Rm = 1 / (water_viscosity(20) * m.Lp_clean20 / 3.6e6 / 1e5)
    J_ref = m.J_avg20 / 3.6e6
    k_res, f_irr, f_irremov = 4.0e11, 0.42, 0.006        # m^-1 per (m3/m2), fractions
    # fouling propensity falls with scour intensity and rises with mixed-liquor solids
    # (empirical exponents in the range reported for HF MBRs; =1 at SAD_m 0.25, MLSS 11.25)
    k_res *= (0.25 / m.SAD_m) ** 0.8 * (X_mt / 11.25) ** 0.5
    Rres = Rirr = Rperm = 0.0
    TMP = np.zeros(n); J = np.zeros(n); Lp = np.zeros(n); events = []
    A_on = mem["A_installed"]
    offline_until = -1
    for i in range(n):
        A = A_on * (m.n_trains - 1) / m.n_trains if i < offline_until else A_on
        Jg = Qh[i] * 1000 / (A * mem["availability"]) / 3.6e6       # m/s gross
        mu = water_viscosity(T[i])
        dV = Jg * 3600 * dt                                          # m3/m2 filtered
        dR = k_res * (Jg / J_ref) ** 2 * dV
        Rres += dR; Rirr += f_irr * dR; Rperm += f_irremov * dR
        TMP[i] = mu * Jg * (Rm + Rres + Rirr + Rperm) / 1e5          # bar
        J[i] = Jg * 3.6e6
        Lp[i] = J[i] / TMP[i] * (water_viscosity(T[i]) / water_viscosity(20))
        if i % (7 * 24) == 0 and i > 0:                               # weekly maintenance clean
            Rres *= 0.25; events.append((t[i], "MC"))
        if TMP[i] > m.TMP_max:                                        # recovery clean (CIP)
            Rres, Rirr = 0.0, Rirr * 0.08
            offline_until = i + 12
            events.append((t[i], "RC"))
    return dict(t=t, T=T, J=J, TMP=TMP, Lp=Lp, events=events)


# ----------------------------------------------------------------------------------
# 8. RETROFIT (MODERNIZATION) CAPACITY CHECK
# ----------------------------------------------------------------------------------
def retrofit_check(inf: Influent, d: DesignBasis, bio: dict, mem: dict, cas: ExistingCAS,
                   m: MembraneSpec) -> dict:
    V_exist = cas.n_aer_tanks * cas.V_aer_each
    px_per_m3 = bio["Px_TSS"] / inf.Q_avg                         # kg TSS / m3 treated
    Qmax_cas = V_exist * cas.X_cas / (px_per_m3 * bio["SRT_total"])
    Qmax_mbr = (V_exist * d.X_bio + mem["V_mt"] * bio["X_mt"]) / (px_per_m3 * bio["SRT_total"])
    clar_area = cas.n_clarifiers * math.pi * cas.clarifier_D**2 / 4
    clar_vol = clar_area * cas.clarifier_swd
    return dict(X_cas=cas.X_cas, X_mbr=d.X_bio, V_existing=V_exist, V_mbr_required=bio["V_bio"], fits=bio["V_bio"] <= V_exist,
                Qmax_CAS=Qmax_cas, Qmax_MBR=Qmax_mbr, capacity_gain=Qmax_mbr / Qmax_cas,
                freed_volume=V_exist - bio["V_bio"], clarifier_area_released=clar_area,
                clarifier_volume_released=clar_vol,
                MT_footprint=mem["L_train"] * mem["W_train"] * m.n_trains)


# ----------------------------------------------------------------------------------
# 9. SCALE-UP: pilot (1 module)  ->  cassette  ->  train  ->  full plant
# ----------------------------------------------------------------------------------
def scale_up(inf: Influent, d: DesignBasis, k: Kinetics, m: MembraneSpec, mem: dict,
             bio: dict, aer: dict, AOR: float) -> dict:
    """Modular 'numbering-up' of membranes + similarity-based scale-up of biology/aeration.
    Scale-invariant (kept constant): flux, SAD_m, SRT, MLSS, HRT, F/M, R, IR, cleaning
    protocol (chemical dose per m2), filtration/relax cycle, fibre packing.
    Scale-variant (recomputed): diffuser submergence -> SOTE, blower/pump efficiency,
    mixing power density, hydraulic distribution between cassettes, diurnal peaking."""
    Q_full = inf.Q_avg
    Q_pilot = m.module_area * mem["J_operating_avg"] * mem["availability"] * 24 / 1000
    S = Q_full / Q_pilot

    V_bio_p = bio["V_bio"] / S
    V_anox_p = bio["V_anox"] / S
    sub_pilot = 2.2
    aer_p = aeration_design(inf, d, m, bio, {**mem, "air_scour_Nm3h": m.module_area * m.SAD_m},
                            AOR / S, sub=sub_pilot)
    air_scour_p = m.module_area * m.SAD_m

    E_full = energy_balance(Q_full, aer["design_air_Nm3h"] / 1.25 * 1.0, mem["air_scour_Nm3h"],
                            bio["V_anox"], d.R_ras, bio["IR"], d.sub_diffuser, m.scour_sub,
                            blower_eff=0.75, pump_eff=0.70, mix_W_m3=d.anox_mix_W_m3)
    E_pilot = energy_balance(Q_pilot, aer_p["design_air_Nm3h"] / 1.25, air_scour_p,
                             V_anox_p, d.R_ras, bio["IR"], sub_pilot, 2.0,
                             blower_eff=0.45, pump_eff=0.40, mix_W_m3=15.0, misc_kWh_m3=0.10)

    # Hydraulic maldistribution between cassettes at full scale (manifold headloss criterion)
    # keep permeate manifold headloss < 10 % of TMP -> flux non-uniformity < ~5 %
    n_c = mem["n_cas_train"]
    maldist = 1 + 0.012 * n_c                     # empirical: peak-cassette flux factor

    levels = [
        ("Pilot\n(1 module)", 1, m.module_area, Q_pilot),
        ("Cassette", m.modules_per_cassette, mem["A_cassette"], Q_pilot * m.modules_per_cassette),
        ("Train", m.modules_per_cassette * n_c, mem["A_cassette"] * n_c,
         Q_pilot * m.modules_per_cassette * n_c),
        ("Full plant", mem["n_modules"], mem["A_installed"], Q_pilot * mem["n_modules"]),
    ]
    invariants = {
        "Gross flux (L/m2.h)": mem["J_operating_avg"],
        "SAD_m (Nm3/m2.h)": m.SAD_m,
        "SAD_p (Nm3/m3)": mem["SAD_p"],
        "SRT total (d)": bio["SRT_total"],
        "MLSS bio / MT (g/L)": f'{d.X_bio:.1f} / {bio["X_mt"]:.2f}',
        "HRT (h)": bio["HRT_h"],
        "F/M (kg BOD/kg VSS.d)": bio["FM"],
        "Recycles R / IR": f'{d.R_ras:.1f} / {bio["IR"]:.1f}',
        "Filtration/relax (min)": f"{m.t_filt:.0f} / {m.t_relax:.0f}",
    }
    variants = {
        "Diffuser submergence (m)": (sub_pilot, d.sub_diffuser),
        "Process SOTE (%)": (aer_p["summer max-day"]["SOTE"] * 100, aer["summer max-day"]["SOTE"] * 100),
        "Process air (Nm3/m3)": (aer_p["design_air_Nm3h"] / 1.25 * 24 / Q_pilot,
                                  aer["design_air_Nm3h"] / 1.25 * 24 / Q_full),
        "Blower efficiency (-)": (0.45, 0.75),
        "Mixing (W/m3)": (15.0, d.anox_mix_W_m3),
        "Peak-cassette flux factor": (1.0, maldist),
        "Specific energy (kWh/m3)": (E_pilot["kWh_m3"]["TOTAL"], E_full["kWh_m3"]["TOTAL"]),
    }
    return dict(Q_pilot=Q_pilot, scale_factor=S, V_bio_pilot=V_bio_p, levels=levels,
                invariants=invariants, variants=variants, E_full=E_full, E_pilot=E_pilot)


# ----------------------------------------------------------------------------------
# 10. DIAGRAMS
# ----------------------------------------------------------------------------------
C_TANK = "#dceefb"; C_EDGE = "#1f4e79"; C_AIR = "#2e8b57"; C_SLUDGE = "#8b5a2b"
C_REC = "#c0392b"; C_PERM = "#1565c0"; C_CHEM = "#7b3fa0"


def _box(ax, x, y, w, h, title, sub="", fc="#eef4fa", ec=C_EDGE, fs=9.5):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.02,rounding_size=0.12",
                                fc=fc, ec=ec, lw=1.6))
    ax.text(x + w / 2, y + h - 0.15, title, ha="center", va="top", fontsize=fs, weight="bold",
            color="#0f2236")
    if sub:
        ax.text(x + w / 2, y + (h - 0.45) / 2, sub, ha="center", va="center", fontsize=fs - 2,
                color="#222", linespacing=1.35)


def _arrow(ax, pts, color=C_EDGE, lw=2.0, ls="-", head=True):
    xs, ys = zip(*pts)
    ax.plot(xs[:-1] + (xs[-1],), ys[:-1] + (ys[-1],), color=color, lw=lw, ls=ls,
            solid_capstyle="round", zorder=1)
    if head:
        ax.annotate("", xy=pts[-1], xytext=pts[-2],
                    arrowprops=dict(arrowstyle="-|>", color=color, lw=lw, mutation_scale=16), zorder=2)


def _tank(ax, x, y, w, h, title, lines, fc=C_TANK):
    ax.add_patch(Rectangle((x, y), w, h, fc=fc, ec=C_EDGE, lw=2.0))
    ax.plot([x, x + w], [y + h * 0.88] * 2, color="#5dade2", lw=1.2, ls=(0, (6, 3)))
    ax.text(x + w / 2, y + h - 0.12, title, ha="center", va="top", fontsize=10, weight="bold",
            color="#0f2236")
    ax.text(x + w / 2, y + h * 0.48, lines, ha="center", va="center", fontsize=7.6,
            linespacing=1.35, color="#1b1b1b")


def draw_pfd(inf, d, m, mem, bio, aer, fname):
    fig, ax = plt.subplots(figsize=(19, 9.5))
    ax.set_xlim(0, 33); ax.set_ylim(0, 14); ax.axis("off")
    Qa = inf.Q_avg

    ax.text(16.5, 13.6, "MBR Modernization - Process Flow Diagram (MLE-MBR, submerged hollow-fibre)",
            ha="center", fontsize=15, weight="bold", color="#0f2236")
    ax.text(16.5, 13.05, f"Q_avg = {Qa:,.0f} m³/d   |   Q_peak-hour = {Qa*inf.pf_peakhour:,.0f} m³/d   |   "
            f"Winter design T = {inf.T_min:.0f} °C   |   Effluent: NH₄-N ≤ {d.NH4_eff:.0f}, TN ≤ {d.TN_eff:.0f}, "
            f"TP ≤ {d.TP_eff} mg/L, TSS < 1 mg/L", ha="center", fontsize=9.5, color="#333")

    # Pretreatment
    _arrow(ax, [(0.1, 8.0), (1.0, 8.0)]); ax.text(0.1, 8.25, "Raw\nWW", fontsize=8.5, weight="bold")
    _box(ax, 1.0, 7.0, 2.3, 2.0, "Coarse\nscreen", "6 mm bar\nscreen")
    _arrow(ax, [(3.3, 8.0), (3.8, 8.0)])
    _box(ax, 3.8, 7.0, 2.4, 2.0, "Grit &\ngrease", "aerated\ngrit chamber")
    _arrow(ax, [(6.2, 8.0), (6.7, 8.0)])
    _box(ax, 6.7, 7.0, 2.5, 2.0, "Fine\nscreen", "≤1 mm punched\nplate (fibre\nprotection)", fc="#fff4e0")
    _arrow(ax, [(9.2, 8.0), (10.0, 8.0)])

    # Bioreactors
    _tank(ax, 10.0, 6.0, 4.4, 3.6, "ANOXIC",
          f"V = {bio['V_anox']:,.0f} m³\nMLSS {d.X_bio:.1f} g/L\nSDNR {bio['SDNR_T']:.3f} gN/gVSS·d\n"
          f"NO₃ removed {bio['NO3_removed']:,.0f} kg/d\nmixers {d.anox_mix_W_m3:.0f} W/m³")
    _tank(ax, 14.4, 6.0, 6.4, 3.6, "AEROBIC (nitrification)",
          f"V = {bio['V_aer']:,.0f} m³   SWD {d.swd_bio} m\nSRT_aer {bio['SRT_aer']:.1f} d / SRT_tot {bio['SRT_total']:.1f} d\n"
          f"DO {d.DO_aer} mg/L   α = {aer['winter']['alpha']:.2f}\n"
          f"AOR {aer['summer max-day']['AOR']:,.0f} kg O₂/d (max-day)")
    for xx in np.arange(14.8, 20.6, 0.45):  # fine-bubble diffusers
        ax.add_patch(Circle((xx, 6.25), 0.07, color=C_AIR))
    for xx in (11.2, 13.2):                  # mixers
        ax.plot([xx, xx], [6.4, 7.0], color="#555", lw=1.5); ax.plot([xx - .25, xx + .25], [6.45, 6.35], color="#555", lw=2)

    _arrow(ax, [(20.8, 7.4), (21.6, 7.4)])
    ax.text(21.2, 7.6, f"{1+d.R_ras:.0f}Q", ha="center", fontsize=8, color=C_EDGE)

    # Membrane tank
    _tank(ax, 21.6, 6.0, 4.8, 3.6, f"MEMBRANE TANKS ×{m.n_trains}", "", fc="#e6f5ec")
    for j in range(4):
        x0 = 22.0 + j * 1.05
        ax.add_patch(Rectangle((x0, 6.55), 0.75, 1.6, fc="white", ec="#2c3e50", lw=1))
        for f in np.linspace(x0 + 0.1, x0 + 0.65, 6):
            ax.plot([f, f], [6.6, 8.1], color="#7f8c8d", lw=0.6)
    ax.text(24.0, 8.55, f"{mem['n_cassettes']} cassettes · {mem['A_installed']:,.0f} m²\n"
            f"J_avg {mem['J_operating_avg']:.1f} LMH · MLSS {bio['X_mt']:.1f} g/L",
            ha="center", va="center", fontsize=7.4, linespacing=1.3)

    # Permeate
    _arrow(ax, [(26.4, 8.6), (27.0, 8.6)], color=C_PERM)
    _box(ax, 27.0, 7.6, 2.4, 2.0, "Permeate\npumps", f"VFD, {m.t_filt:.0f}/{m.t_relax:.0f} min\nfilt./relax\nTMP ≤ {m.TMP_max} bar", fc="#e3f0ff", ec=C_PERM)
    _arrow(ax, [(29.4, 8.6), (30.0, 8.6)], color=C_PERM)
    _box(ax, 30.0, 7.6, 2.6, 2.0, "UV / reuse", "Effluent\nTSS<1, turb.<0.2 NTU\nBOD<3 mg/L", fc="#e3f0ff", ec=C_PERM)

    # RAS: membrane tank -> aerobic (above)
    _arrow(ax, [(24.0, 9.6), (24.0, 11.4), (19.6, 11.4), (19.6, 9.6)], color=C_REC, lw=2.2)
    ax.text(21.8, 11.6, f"RAS  R = {d.R_ras:.0f}Q  ({d.R_ras*Qa:,.0f} m³/d)", ha="center", fontsize=8.5, color=C_REC, weight="bold")
    # MLR: aerobic -> anoxic
    _arrow(ax, [(17.0, 9.6), (17.0, 10.5), (12.2, 10.5), (12.2, 9.6)], color=C_REC, lw=2.2, ls=(0, (5, 2)))
    ax.text(14.6, 10.7, f"MLR (nitrate)  IR = {bio['IR']:.1f}Q", ha="center", fontsize=8.5, color=C_REC, weight="bold")

    # Blowers / air
    _box(ax, 15.8, 1.2, 3.4, 1.8, "Process blowers", f"{aer['design_air_Nm3h']:,.0f} Nm³/h (max-day)\nturbo, DO-cascade control", fc="#eaf7ef", ec=C_AIR)
    _arrow(ax, [(17.5, 3.0), (17.5, 6.0)], color=C_AIR)
    _box(ax, 21.6, 1.2, 3.4, 1.8, "Scour blowers", f"{mem['air_scour_Nm3h']:,.0f} Nm³/h\nSAD_m {m.SAD_m} Nm³/m²·h", fc="#eaf7ef", ec=C_AIR)
    _arrow(ax, [(23.3, 3.0), (23.3, 6.0)], color=C_AIR)

    # WAS / sludge
    _arrow(ax, [(25.8, 6.0), (25.8, 3.6), (27.0, 3.6)], color=C_SLUDGE)
    _box(ax, 27.0, 2.6, 3.6, 2.0, "Sludge line", f"WAS {bio['Px_TSS']:,.0f} kg TSS/d\n"
         f"≈{bio['Px_TSS']/bio['X_mt']:,.0f} m³/d → thickening\n→ dewatering", fc="#f6ece2", ec=C_SLUDGE)

    # Chemicals
    _box(ax, 27.0, 10.8, 3.6, 1.8, "CIP / dosing", "NaOCl 500-1000 ppm (MC/RC)\nCitric acid 2000 ppm\n"
         f"FeCl₃ {bio['Fe_kgd']:,.0f} kg Fe/d (P)", fc="#f3eafa", ec=C_CHEM)
    _arrow(ax, [(27.0, 11.2), (26.0, 11.2), (26.0, 9.6)], color=C_CHEM, ls=(0, (3, 2)))
    _arrow(ax, [(28.8, 10.8), (28.8, 10.2), (15.5, 10.2), (15.5, 9.6)], color=C_CHEM, ls=(0, (1, 2)), lw=1.4)

    # Legend
    ly = 4.6
    for i, (c, lab, ls) in enumerate([(C_EDGE, "Mixed liquor / wastewater", "-"), (C_PERM, "Permeate", "-"),
                                      (C_REC, "Recycles", "-"), (C_AIR, "Air", "-"),
                                      (C_SLUDGE, "Waste sludge", "-"), (C_CHEM, "Chemicals", ":")]):
        ax.plot([0.5, 1.4], [ly - i * 0.55] * 2, color=c, lw=2.2, ls=ls)
        ax.text(1.6, ly - i * 0.55, lab, va="center", fontsize=8.5)
    ax.text(0.5, 5.2, "Legend", weight="bold", fontsize=9.5)

    ax.text(5.0, 4.6, f"Total bioreactor volume {bio['V_bio']:,.0f} m³  +  membrane tanks {mem['V_mt']:,.0f} m³\n"
            f"HRT {bio['HRT_h']:.1f} h  ·  F/M {bio['FM']:.3f} kg BOD/kg VSS·d  ·  Y_obs {bio['Y_obs']:.2f} kg TSS/kg BOD\n"
            f"Anoxic fraction {bio['f_anox']*100:.0f} %  ·  NOx formed {bio['NOx']:.1f} mg N/L\n"
            f"Membrane area governed by: {mem['governing']}",
            fontsize=9, va="top", linespacing=1.5,
            bbox=dict(boxstyle="round", fc="#fbfbfb", ec="#999"))
    fig.savefig(fname, dpi=170, bbox_inches="tight"); plt.close(fig)


def draw_scaleup(sc, m, fname):
    fig = plt.figure(figsize=(18, 10))
    ax = fig.add_axes([0.02, 0.48, 0.96, 0.48]); ax.axis("off"); ax.set_xlim(0, 32); ax.set_ylim(0, 9)
    ax.text(16, 8.6, "Scale-up strategy: modular numbering-up of membranes + similarity scale-up of biology",
            ha="center", fontsize=14, weight="bold")
    xs = [0.8, 8.8, 16.8, 24.8]
    mults = [f"×{m.modules_per_cassette}", f"×{sc['levels'][2][1]//m.modules_per_cassette}",
             f"×{sc['levels'][3][1]//sc['levels'][2][1]}"]
    for i, ((lab, nmod, A, Q), x) in enumerate(zip(sc["levels"], xs)):
        _box(ax, x, 2.6, 6.4, 5.2, lab.replace("\n", " "),
             f"{nmod:,} module(s)\nArea {A:,.0f} m²\nQ ≈ {Q:,.1f} m³/d\n"
             f"scale factor {Q/sc['Q_pilot']:,.0f}×", fc=["#fff4e0", "#eef4fa", "#e6f5ec", "#e3f0ff"][i], fs=12)
        # small icon of modules
        nshow = min(nmod, 24)
        cols = 12
        for j in range(nshow):
            r, c = divmod(j, cols)
            ax.add_patch(Rectangle((x + 0.45 + c * 0.47, 2.85 + r * 0.55), 0.35, 0.45, fc="white", ec="#555", lw=.6))
        if i < 3:
            _arrow(ax, [(x + 6.5, 5.2), (xs[i + 1] - 0.1, 5.2)], lw=2.5)
            ax.text((x + 6.5 + xs[i + 1]) / 2, 5.5, mults[i], ha="center", fontsize=12, weight="bold", color=C_REC)
    ax.text(16, 1.6, "Kept constant across scales (scale-invariant):  " +
            "  ·  ".join(f"{k}: {v:.3g}" if isinstance(v, float) else f"{k}: {v}" for k, v in list(sc["invariants"].items())[:5]),
            ha="center", fontsize=9)
    ax.text(16, 0.9, "  ·  ".join(f"{k}: {v:.3g}" if isinstance(v, float) else f"{k}: {v}" for k, v in list(sc["invariants"].items())[5:]),
            ha="center", fontsize=9)

    # Bottom left: energy breakdown pilot vs full
    ax2 = fig.add_axes([0.06, 0.06, 0.42, 0.34])
    keys = [k for k in sc["E_full"]["kWh_m3"] if k != "TOTAL"]
    pil = [sc["E_pilot"]["kWh_m3"][k] for k in keys]; ful = [sc["E_full"]["kWh_m3"][k] for k in keys]
    bottom_p = bottom_f = 0
    cmap = plt.get_cmap("tab10")
    for i, k in enumerate(keys):
        ax2.bar(0, pil[i], bottom=bottom_p, color=cmap(i), width=0.55, label=k.replace("_", " "))
        ax2.bar(1, ful[i], bottom=bottom_f, color=cmap(i), width=0.55)
        bottom_p += pil[i]; bottom_f += ful[i]
    ax2.set_xticks([0, 1]); ax2.set_xticklabels([f"Pilot\n({sc['Q_pilot']:.1f} m³/d)", f"Full scale\n({sc['Q_pilot']*sc['scale_factor']:,.0f} m³/d)"])
    ax2.text(0, bottom_p + 0.03, f"{bottom_p:.2f}", ha="center", weight="bold")
    ax2.text(1, bottom_f + 0.03, f"{bottom_f:.2f}", ha="center", weight="bold")
    ax2.set_ylabel("Specific energy, kWh/m³ permeate"); ax2.set_title("Energy demand: pilot vs full scale")
    ax2.legend(fontsize=7.5, loc="upper right"); ax2.grid(axis="y", alpha=.3)

    # Bottom right: scale-variant parameter table
    ax3 = fig.add_axes([0.54, 0.06, 0.43, 0.34]); ax3.axis("off")
    rows = [[k, f"{v[0]:.3g}", f"{v[1]:.3g}"] for k, v in sc["variants"].items()]
    tb = ax3.table(cellText=rows, colLabels=["Scale-variant parameter", "Pilot", "Full scale"],
                   loc="center", cellLoc="center", colWidths=[0.55, 0.2, 0.2])
    tb.auto_set_font_size(False); tb.set_fontsize(9.5); tb.scale(1, 1.6)
    for (r, c), cell in tb.get_celld().items():
        if r == 0: cell.set_facecolor("#1f4e79"); cell.set_text_props(color="white", weight="bold")
    ax3.set_title("What changes on scale-up (must be corrected, not copied)", fontsize=11)
    fig.savefig(fname, dpi=160, bbox_inches="tight"); plt.close(fig)


def plot_fouling(sim, m, fname):
    fig, axs = plt.subplots(3, 1, figsize=(14, 9.5), sharex=True)
    t = sim["t"]
    axs[0].plot(t, sim["J"], lw=0.4, color=C_PERM); axs[0].set_ylabel("Gross flux\n(L/m²·h)")
    ax0b = axs[0].twinx(); ax0b.plot(t, sim["T"], color="#e67e22", lw=1.5); ax0b.set_ylabel("T (°C)", color="#e67e22")
    axs[1].plot(t, sim["TMP"], lw=0.5, color="#c0392b"); axs[1].axhline(m.TMP_max, ls="--", color="k", lw=1)
    axs[1].text(t[-1], m.TMP_max + 0.005, "recovery-clean trigger", ha="right", fontsize=8)
    axs[1].set_ylabel("TMP (bar)")
    axs[2].plot(t, sim["Lp"], lw=0.5, color=C_AIR); axs[2].set_ylabel("Permeability\n@20°C (LMH/bar)")
    axs[2].set_xlabel("Operating time (days)")
    for tt, ev in sim["events"]:
        if ev == "RC":
            for a in axs[1:]:
                a.axvline(tt, color="#7b3fa0", lw=1.2, alpha=.7)
    axs[1].plot([], [], color="#7b3fa0", label="Recovery clean (CIP)"); axs[1].legend(loc="upper left", fontsize=8)
    axs[0].set_title("Membrane performance simulation: diurnal & storm flows, seasonal temperature, weekly maintenance cleans")
    for a in axs: a.grid(alpha=.3)
    fig.tight_layout(); fig.savefig(fname, dpi=160); plt.close(fig)


def plot_sensitivity(inf, d, k, m, fname):
    fig, axs = plt.subplots(1, 2, figsize=(15, 5.6))
    # (a) membrane area vs design temperature for several design fluxes
    Ts = np.linspace(8, 24, 33)
    for J in (20, 25, 30, 35):
        A = []
        for T in Ts:
            i2 = Influent(**{**asdict(inf), "T_min": T}); m2 = MembraneSpec(**{**asdict(m), "J_avg20": J, "J_mm20": J * 1.2, "J_peak20": J * 1.6})
            A.append(membrane_design(i2, m2)["A_installed"] / 1000)
        axs[0].plot(Ts, A, lw=2, label=f"J_avg,20 = {J} LMH")
    axs[0].set_xlabel("Winter design temperature (°C)"); axs[0].set_ylabel("Installed membrane area (×1000 m²)")
    axs[0].set_title("(a) Membrane area sensitivity (viscosity-corrected flux)"); axs[0].legend(); axs[0].grid(alpha=.3)

    # (b) MLSS optimisation: volume decreases, alpha penalty increases air
    Xs = np.linspace(5, 14, 28); V, AIR = [], []
    for X in Xs:
        d2 = DesignBasis(**{**asdict(d), "X_bio": X})
        mem = membrane_design(inf, m); bio = biological_design(inf, d2, k, mem)
        aer = aeration_design(inf, d2, m, bio, mem, oxygen_demand(inf, k, bio))
        V.append(bio["V_bio"]); AIR.append(aer["design_air_Nm3h"])
    axs[1].plot(Xs, V, color=C_EDGE, lw=2.2, label="Bioreactor volume")
    axs[1].set_xlabel("Bioreactor MLSS (g/L)"); axs[1].set_ylabel("Volume (m³)", color=C_EDGE)
    b = axs[1].twinx(); b.plot(Xs, AIR, color=C_AIR, lw=2.2, label="Process air (max-day)")
    b.set_ylabel("Process air (Nm³/h)", color=C_AIR)
    axs[1].axvspan(8, 12, color="#f9e79f", alpha=.35); axs[1].text(10, max(V) * 0.95, "typical MBR\nwindow", ha="center", fontsize=9)
    axs[1].set_title("(b) MLSS trade-off: footprint vs α-factor aeration penalty"); axs[1].grid(alpha=.3)
    fig.tight_layout(); fig.savefig(fname, dpi=160); plt.close(fig)


def plot_retrofit(rf, fname):
    fig, axs = plt.subplots(1, 2, figsize=(13, 5))
    axs[0].bar([f"Existing CAS\n(MLSS {rf['X_cas']} g/L)", f"MBR in same tanks\n(MLSS {rf['X_mbr']} g/L)"], [rf["Qmax_CAS"], rf["Qmax_MBR"]],
               color=["#95a5a6", C_EDGE], width=.55)
    for i, v in enumerate([rf["Qmax_CAS"], rf["Qmax_MBR"]]):
        axs[0].text(i, v * 1.01, f"{v:,.0f} m³/d", ha="center", weight="bold")
    axs[0].set_ylabel("Treatment capacity at same SRT & nutrient targets (m³/d)")
    axs[0].set_title(f"Capacity gain ×{rf['capacity_gain']:.2f} without new bioreactor volume")
    axs[1].bar(["Existing aeration\nvolume", "MBR bio volume\nrequired"], [rf["V_existing"], rf["V_mbr_required"]],
               color=["#95a5a6", C_AIR], width=.55)
    axs[1].set_ylabel("m³"); axs[1].set_title(f"Freed volume {rf['freed_volume']:,.0f} m³ · clarifiers ({rf['clarifier_area_released']:,.0f} m²) released")
    for a in axs: a.grid(axis="y", alpha=.3)
    fig.tight_layout(); fig.savefig(fname, dpi=160); plt.close(fig)


# ----------------------------------------------------------------------------------
# 11. MAIN
# ----------------------------------------------------------------------------------
def main():
    inf, d, k, m, cas = Influent(), DesignBasis(), Kinetics(), MembraneSpec(), ExistingCAS()

    mem = membrane_design(inf, m)
    bio = biological_design(inf, d, k, mem)
    AOR = oxygen_demand(inf, k, bio)
    aer = aeration_design(inf, d, m, bio, mem, AOR)
    rf = retrofit_check(inf, d, bio, mem, cas, m)
    sc = scale_up(inf, d, k, m, mem, bio, aer, AOR)
    sim = fouling_simulation(inf, m, mem, X_mt=bio["X_mt"])

    draw_pfd(inf, d, m, mem, bio, aer, f"{OUT}/01_process_flow_diagram.png")
    draw_scaleup(sc, m, f"{OUT}/02_scale_up_strategy.png")
    plot_fouling(sim, m, f"{OUT}/03_membrane_fouling_TMP.png")
    plot_sensitivity(inf, d, k, m, f"{OUT}/04_design_sensitivity.png")
    plot_retrofit(rf, f"{OUT}/05_retrofit_capacity.png")

    n_rc = sum(1 for _, e in sim["events"] if e == "RC")
    E = sc["E_full"]["kWh_m3"]
    lines = [
        "# MBR Preliminary Design Report (auto-generated by mbr_design.py)\n",
        f"Design flow {inf.Q_avg:,.0f} m³/d avg, {inf.Q_avg*inf.pf_peakhour:,.0f} m³/d peak hour; winter {inf.T_min} °C.\n",
        "## Biological process (MLE)",
        f"- Min. nitrification SRT at {inf.T_min} °C: {bio['SRT_nit_min']:.1f} d → aerobic SRT {bio['SRT_aer']:.1f} d, total SRT {bio['SRT_total']:.1f} d",
        f"- Anoxic {bio['V_anox']:,.0f} m³ + aerobic {bio['V_aer']:,.0f} m³ = {bio['V_bio']:,.0f} m³ (anoxic fraction {bio['f_anox']*100:.0f} %)",
        f"- MLSS bio/membrane tank: {d.X_bio:.1f} / {bio['X_mt']:.2f} g/L; HRT {bio['HRT_h']:.1f} h; F/M {bio['FM']:.3f}",
        f"- Sludge production {bio['Px_TSS']:,.0f} kg TSS/d (incl. {bio['chem_sludge']:,.0f} kg/d chemical); Y_obs {bio['Y_obs']:.2f} kg TSS/kg BOD",
        f"- NOx formed {bio['NOx']:.1f} mg/L, internal recycle IR = {bio['IR']:.2f}Q, NO₃ removed {bio['NO3_removed']:,.0f} kg N/d",
        f"- FeCl₃ for TP {d.TP_eff} mg/L: {bio['Fe_kgd']:,.0f} kg Fe/d; residual alkalinity {bio['alk_eff']:.0f} mg/L CaCO₃ (supplement {bio['alk_add_kgd']:,.0f} kg/d)",
        "\n## Membranes",
        f"- Flux viscosity correction at {inf.T_min} °C: ×{mem['mu_ratio']:.3f}; availability {mem['availability']*100:.1f} %",
        f"- Area required: avg N-1 = {mem['A_avg']:,.0f} m², max-month = {mem['A_mm']:,.0f} m², peak-hour = {mem['A_ph']:,.0f} m² → governed by {mem['governing']}",
        f"- Installed: {m.n_trains} trains × {mem['n_cas_train']} cassettes = {mem['n_cassettes']} cassettes, {mem['n_modules']:,} modules, {mem['A_installed']:,.0f} m²",
        f"- Operating avg gross flux {mem['J_operating_avg']:.1f} LMH; SAD_m {m.SAD_m} → scour air {mem['air_scour_Nm3h']:,.0f} Nm³/h; SAD_p {mem['SAD_p']:.1f} Nm³/m³",
        f"- Membrane tank volume {mem['V_mt']:,.0f} m³ (train {mem['L_train']:.1f} × {mem['W_train']:.1f} × {m.mt_depth} m); packing {mem['packing_density']:.0f} m²/m³",
        f"- 240-day simulation: {n_rc} recovery cleans (TMP > {m.TMP_max} bar), weekly maintenance cleans",
        "\n## Aeration",
        *[f"- {c}: α={aer[c]['alpha']:.2f}, AOR {aer[c]['AOR']:,.0f} kg/d, scour-air O₂ credit {aer[c]['AOTR_scour']:,.0f} kg/d, "
          f"SOTR {aer[c]['SOTR']:,.0f} kg/d, air {aer[c]['air_Nm3h']:,.0f} Nm³/h" for c in ("winter", "summer", "summer max-day")],
        "\n## Energy (full scale, average day)",
        *[f"- {k_}: {v:.3f} kWh/m³" for k_, v in E.items()],
        "\n## Modernization (retrofit) check",
        f"- Existing aeration volume {rf['V_existing']:,.0f} m³ vs MBR bio volume {rf['V_mbr_required']:,.0f} m³ → fits: {rf['fits']}",
        f"- Capacity of existing tanks: CAS {rf['Qmax_CAS']:,.0f} m³/d → MBR {rf['Qmax_MBR']:,.0f} m³/d (×{rf['capacity_gain']:.2f})",
        f"- Secondary clarifiers released ({rf['clarifier_volume_released']:,.0f} m³) → membrane tanks / EQ / sludge storage",
        "\n## Scale-up (pilot → full)",
        f"- Pilot = 1 module ({m.module_area} m²) treating {sc['Q_pilot']:.1f} m³/d; scale factor {sc['scale_factor']:,.0f}×",
        *[f"- invariant · {k_}: {v:.3g}" if isinstance(v, float) else f"- invariant · {k_}: {v}" for k_, v in sc["invariants"].items()],
        *[f"- variant · {k_}: pilot {v[0]:.3g} → full {v[1]:.3g}" for k_, v in sc["variants"].items()],
    ]
    with open(f"{OUT}/design_report.md", "w") as fh:
        fh.write("\n".join(lines))
    with open(f"{OUT}/design_results.json", "w") as fh:
        json.dump(dict(membrane=mem, biology=bio, aeration=aer, retrofit=rf,
                       energy_full=sc["E_full"], energy_pilot=sc["E_pilot"]), fh, indent=2, default=str)
    print("\n".join(lines))


if __name__ == "__main__":
    main()
