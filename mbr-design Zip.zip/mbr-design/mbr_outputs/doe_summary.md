# DOE / response-surface results (Python cross-check of the JMP analysis)

Design: face-centred CCD, 5 factors, 48 runs (32 factorial + 10 axial + 6 centre).

## Model fit (full quadratic, 21 terms)
| Response | R² | R² adj | RMSE |
|---|---|---|---|
| Energy_kWh_m3 | 0.9980 | 0.9964 | 0.00658 |
| Footprint_m3 | 0.9996 | 0.9992 | 63.17 |
| Membrane_area_req_m2 | 1.0000 | 1.0000 | 32.93 |
| Mean_TMP_bar | 0.8957 | 0.8184 | 0.006733 |
| ProcessAir_Nm3h | 0.9998 | 0.9996 | 24.87 |
| Sludge_kgTSS_d | 0.9983 | 0.9971 | 4.893 |
| RC_per_year | 0.9339 | 0.8849 | 0.8412 |

## Desirability optimum (Tmin locked at 12 °C)
Overall desirability D = 0.606

| Factor | Optimum | Baseline design |
|---|---|---|
| MLSS_gL | 9.89 | 9.0 |
| Flux20_LMH | 29.9 | 25.0 |
| SADm | 0.344 | 0.25 |
| Tmin_C | 12 | 12.0 |
| SRTaer_d | 12 | 15.0 |

| Response | RSM prediction | Full model at optimum | Baseline design |
|---|---|---|---|
| Energy_kWh_m3 | 0.7155 | 0.7037 | 0.6559 |
| Footprint_m3 | 6537 | 6312 | 8224 |
| Membrane_area_req_m2 | 3.058e+04 | 3.061e+04 | 3.66e+04 |
| Mean_TMP_bar | 0.1139 | 0.1148 | 0.1186 |
| ProcessAir_Nm3h | 7745 | 7689 | 7404 |
| Sludge_kgTSS_d | 4166 | 4193 | 4095 |
| RC_per_year | 1.664 | 3.042 | 1.521 |