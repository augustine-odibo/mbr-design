// Builds MBR_Design_Report.docx from the model outputs in ./mbr_outputs
const fs = require("fs");
const path = require("path");
const {
  Document, Packer, Paragraph, TextRun, HeadingLevel, AlignmentType, Table, TableRow, TableCell,
  WidthType, ShadingType, BorderStyle, ImageRun, PageBreak, Footer, Header, PageNumber,
  TableOfContents, LevelFormat, VerticalAlign,
} = require("docx");

const OUT = "mbr_outputs";
const R = JSON.parse(fs.readFileSync(`${OUT}/design_results.json`, "utf8"));
const mem = R.membrane, bio = R.biology, aer = R.aeration, rf = R.retrofit;
const EF = R.energy_full, EP = R.energy_pilot;

const f0 = (n) => Number(n).toLocaleString("en-US", { maximumFractionDigits: 0 });
const f1 = (n) => Number(n).toLocaleString("en-US", { minimumFractionDigits: 1, maximumFractionDigits: 1 });
const f2 = (n) => Number(n).toFixed(2);
const f3 = (n) => Number(n).toFixed(3);

const FONT = "Calibri";
const W = 9360; // content width (DXA) for US Letter with 1" margins

// ---------------------------------------------------------------- helpers
function runs(spec, base = {}) {
  // spec: string or array of strings / {t, b, i, sup, sub}
  const arr = Array.isArray(spec) ? spec : [spec];
  return arr.map((s) =>
    typeof s === "string"
      ? new TextRun({ text: s, font: FONT, size: 22, ...base })
      : new TextRun({ text: s.t, bold: s.b, italics: s.i, superScript: s.sup, subScript: s.sub,
                      font: FONT, size: 22, ...base }));
}
const P = (spec, o = {}) => new Paragraph({ children: runs(spec), spacing: { after: 120, line: 276 },
                                            alignment: o.align || AlignmentType.JUSTIFIED, ...o.p });
const H1 = (t) => new Paragraph({ heading: HeadingLevel.HEADING_1, children: [new TextRun({ text: t })],
                                  pageBreakBefore: true });
const H2 = (t) => new Paragraph({ heading: HeadingLevel.HEADING_2, children: [new TextRun({ text: t })] });
const BUL = (spec) => new Paragraph({ children: runs(spec), numbering: { reference: "bullets", level: 0 },
                                      spacing: { after: 60 } });
const NUM = (spec, ref = "steps") => new Paragraph({ children: runs(spec), numbering: { reference: ref, level: 0 },
                                                     spacing: { after: 60 } });
const EQ = (t, tag) => new Paragraph({
  alignment: AlignmentType.CENTER, spacing: { before: 60, after: 100 },
  children: [new TextRun({ text: t, font: "Cambria Math", size: 22, italics: true }),
             ...(tag ? [new TextRun({ text: `     (${tag})`, font: FONT, size: 20 })] : [])],
});

const border = { style: BorderStyle.SINGLE, size: 4, color: "A6B5C4" };
const borders = { top: border, bottom: border, left: border, right: border };
function table(headers, rows, widths, opts = {}) {
  const total = widths.reduce((a, b) => a + b, 0);
  const fs_ = opts.size || 19;
  const cell = (txt, w, hdr, i) => new TableCell({
    borders, width: { size: w, type: WidthType.DXA }, verticalAlign: VerticalAlign.CENTER,
    shading: hdr ? { fill: "1F4E79", type: ShadingType.CLEAR, color: "auto" }
                 : (i % 2 ? { fill: "F2F6FA", type: ShadingType.CLEAR, color: "auto" } : undefined),
    margins: { top: 50, bottom: 50, left: 90, right: 90 },
    children: [new Paragraph({ alignment: opts.alignLeftFirst && w === widths[0] ? AlignmentType.LEFT : AlignmentType.CENTER,
      children: [new TextRun({ text: String(txt), bold: hdr, color: hdr ? "FFFFFF" : "1B1B1B", font: FONT, size: fs_ })] })],
  });
  return new Table({
    width: { size: total, type: WidthType.DXA }, columnWidths: widths,
    rows: [new TableRow({ tableHeader: true, children: headers.map((h, j) => cell(h, widths[j], true, 0)) }),
           ...rows.map((r, i) => new TableRow({ children: r.map((c, j) => cell(c, widths[j], false, i)) }))],
  });
}
const CAP = (t) => new Paragraph({ alignment: AlignmentType.CENTER, spacing: { before: 80, after: 220 },
  children: [new TextRun({ text: t, italics: true, font: FONT, size: 19, color: "404040" })] });
const TCAP = (t) => new Paragraph({ spacing: { before: 200, after: 80 }, keepNext: true,
  children: [new TextRun({ text: t, bold: true, font: FONT, size: 19, color: "1F4E79" })] });

function pngSize(file) {
  const b = fs.readFileSync(file);
  return { w: b.readUInt32BE(16), h: b.readUInt32BE(20) };
}
function FIG(file, caption, widthIn = 6.5) {
  const p = `${OUT}/${file}`;
  const { w, h } = pngSize(p);
  const wpx = widthIn * 96, hpx = (wpx * h) / w;
  return [
    new Paragraph({ alignment: AlignmentType.CENTER, keepNext: true, spacing: { before: 120 },
      children: [new ImageRun({ type: "png", data: fs.readFileSync(p), transformation: { width: wpx, height: hpx },
                                altText: { title: caption, description: caption, name: file } })] }),
    CAP(caption),
  ];
}
function CODE(file) {
  const lines = fs.readFileSync(file, "utf8").replace(/\t/g, "    ").split("\n");
  return lines.map((ln, i) => new Paragraph({
    spacing: { before: 0, after: 0, line: 220 },
    shading: { fill: "F5F5F5", type: ShadingType.CLEAR, color: "auto" },
    children: [new TextRun({ text: String(i + 1).padStart(4, " ") + "  ", font: "Courier New", size: 14, color: "9A9A9A" }),
               new TextRun({ text: ln.length ? ln : " ", font: "Courier New", size: 14 })],
  }));
}

// ---------------------------------------------------------------- DOE data
const csv = fs.readFileSync(`${OUT}/mbr_doe_runs.csv`, "utf8").trim().split(/\r?\n/).map((l) => l.split(","));
const doeHdr = csv[0], doeRows = csv.slice(1);
const col = (name) => doeHdr.indexOf(name);

// ---------------------------------------------------------------- content
const kids = [];

// Title page
kids.push(
  new Paragraph({ spacing: { before: 2400, after: 200 }, alignment: AlignmentType.CENTER,
    children: [new TextRun({ text: "Preliminary Design Analysis of Membrane Bioreactors", bold: true, size: 44, font: FONT, color: "1F4E79" })] }),
  new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 400 },
    children: [new TextRun({ text: "Application in Treatment Sequences for Modernization of Wastewater Treatment Plants", size: 30, font: FONT, color: "1F4E79" })] }),
  new Paragraph({ alignment: AlignmentType.CENTER, border: { bottom: { style: BorderStyle.SINGLE, size: 8, color: "1F4E79", space: 1 } }, spacing: { after: 400 }, children: [] }),
  new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 120 },
    children: runs("Process design model, engineering diagrams, scale-up technique, membrane fouling simulation and response-surface (DOE/JMP) optimisation", { size: 24 }) }),
  new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 1800 },
    children: runs("Including complete Python and JMP (JSL) source code", { size: 24, italics: true }) }),
  new Paragraph({ alignment: AlignmentType.CENTER, children: runs(`Reference case: ${f0(12000)} m³/d municipal plant · MLE-MBR retrofit`, { size: 22 }) }),
  new Paragraph({ alignment: AlignmentType.CENTER, children: runs("October 2026", { size: 22 }) }),
);

// TOC
kids.push(
  new Paragraph({ pageBreakBefore: true, children: [new TextRun({ text: "Contents", bold: true, size: 32, font: FONT, color: "1F4E79" })], spacing: { after: 200 } }),
  new TableOfContents("Contents", { hyperlink: true, headingStyleRange: "1-2" }),
  P([{ t: "Note: ", b: true }, "if the contents list appears empty, right-click it in Word and choose Update Field."], { align: AlignmentType.LEFT }),
);

// 1 Introduction
kids.push(
  H1("1. Introduction and scope"),
  P("Many conventional activated sludge (CAS) plants must now meet tighter nitrogen and phosphorus limits, treat higher flows and produce effluent suitable for reuse, often without room to build new tanks. Inserting a membrane bioreactor (MBR) into the existing treatment sequence addresses all three: membranes replace the secondary clarifiers, which removes the settling limit on mixed-liquor concentration, so the same tank volume holds roughly two to three times more biomass and the effluent is free of suspended solids."),
  P("This report documents a complete preliminary-design model for such a modernization. It sizes the biological process (modified Ludzack-Ettinger configuration with simultaneous chemical phosphorus precipitation), the submerged hollow-fibre membrane system, process and membrane-scour aeration, and the plant's energy demand. It then simulates membrane fouling and cleaning over 240 days, checks whether the MBR fits the existing tanks, sets out a pilot-to-full-scale scale-up procedure, and uses a designed experiment with response-surface methodology to find the best compromise between energy, footprint, membrane area and fouling."),
  P("All calculations are performed by two Python programs (mbr_design.py and doe_runner.py) and one JMP script (MBR_RSM_analysis.jsl), reproduced in full in Appendices A to C. Every number and figure in this report is generated by that code, so the design can be repeated for another plant by changing the input data and re-running it."),
  H2("1.1 Status of the numbers"),
  P("The plant data used here are an illustrative reference case typical of a medium-strength municipal wastewater, not measurements from a specific site. Kinetic and design parameters are standard literature defaults (Metcalf & Eddy, 2014; Judd, 2011). Before detailed design, the influent characterisation, membrane vendor data and pilot-plant fouling results should replace these defaults."),
);

// 2 Design basis
kids.push(
  H1("2. Design basis"),
  TCAP("Table 1. Influent characteristics (after coarse screening, no primary settling)"),
  table(["Parameter", "Value", "Unit"], [
    ["Average dry-weather flow", "12,000", "m³/d"], ["Max-month / max-day / peak-hour factors", "1.30 / 1.60 / 2.00", "–"],
    ["BOD₅", "280", "mg/L"], ["COD", "600", "mg/L"], ["bCOD / BOD₅", "1.6", "–"],
    ["TSS / VSS", "300 / 240", "mg/L"], ["Non-biodegradable VSS fraction", "0.35", "–"],
    ["TKN / NH₄-N", "60 / 40", "mg N/L"], ["Total phosphorus", "9", "mg P/L"], ["Alkalinity", "300", "mg CaCO₃/L"],
    ["Winter / summer design temperature", "12 / 24", "°C"],
  ], [4800, 2600, 1960], { alignLeftFirst: true }),
  TCAP("Table 2. Effluent targets and key design choices"),
  table(["Item", "Value"], [
    ["NH₄-N / TN / TP", "≤ 1 / ≤ 10 / ≤ 0.5 mg/L"], ["TSS, turbidity", "< 1 mg/L, < 0.2 NTU (membrane barrier)"],
    ["Nitrification safety factor on SRT", "1.5 (with 15 d aerobic SRT floor)"], ["Bioreactor MLSS / RAS ratio", "9.0 g/L / 4Q (membrane tank → aerobic)"],
    ["Aerobic DO / DO in nitrate recycle", "2.0 / 1.0 mg/L"], ["Side-water depth / diffuser submergence", "5.5 m / 5.2 m"],
    ["Fine screening ahead of membranes", "≤ 1 mm punched plate (hollow-fibre protection)"],
    ["Phosphorus removal", "FeCl₃ simultaneous precipitation, Fe:P = 1.8 mol/mol"],
  ], [4300, 5060], { alignLeftFirst: true }),
  TCAP("Table 3. Activated sludge kinetic parameters at 20 °C (Metcalf & Eddy, 2014)"),
  table(["Parameter", "Heterotrophs", "Nitrifiers (AOB)"], [
    ["μmax (1/d) · θ", "6.0 · 1.07", "0.90 · 1.072"], ["Half-saturation K (mg/L)", "Ks = 8 (bCOD)", "Kn = 0.50 (NH₄-N); Ko = 0.50 (O₂)"],
    ["Yield Y (g VSS/g)", "0.45", "0.15"], ["Decay b (1/d) · θ", "0.12 · 1.04", "0.17 · 1.029"],
    ["Cell debris fraction fd", "0.15", "–"], ["SDNR (g NO₃-N/g VSS·d) · θ", "0.08 · 1.026", "–"],
  ], [3500, 2700, 3160], { alignLeftFirst: true }),
  TCAP("Table 4. Membrane system design inputs (generic reinforced PVDF hollow fibre, 0.04–0.1 µm)"),
  table(["Parameter", "Value"], [
    ["Module area / modules per cassette", "34.4 m² / 48 (1,651 m² per cassette)"], ["Trains", "4"],
    ["Gross flux at 20 °C: average / max-month / peak-hour", "25 / 30 / 40 L/m²·h"],
    ["Filtration / relaxation cycle", "9 min / 1 min"], ["Maintenance-clean downtime", "0.6 % of operating time"],
    ["Clean-membrane permeability (20 °C)", "400 L/m²·h·bar"], ["Specific scour air demand SAD_m", "0.25 Nm³/m²·h"],
    ["Recovery-clean (CIP) trigger", "TMP > 0.30 bar"],
  ], [5300, 4060], { alignLeftFirst: true }),
);

// 3 Treatment sequence
kids.push(
  H1("3. Treatment sequence and process flow diagram"),
  P("The modernized sequence is: coarse screen (6 mm) → aerated grit and grease removal → fine screen (≤ 1 mm) → anoxic zone → aerobic zone → submerged membrane tanks → permeate pumps → UV disinfection or reuse. Fine screening is essential because hair and fibres wrap around hollow fibres and are the most common cause of irreversible membrane damage."),
  P("Mixed liquor is returned from the membrane tanks to the aerobic zone at 4Q. This keeps the solids concentration at the membranes about 25 % higher than in the bioreactor, and sends the high-oxygen membrane-tank liquor to the aerobic zone rather than the anoxic zone, where it would suppress denitrification. A separate internal recycle carries nitrate from the aerobic to the anoxic zone. Waste sludge is drawn from the membrane tanks, where it is most concentrated."),
  ...FIG("01_process_flow_diagram.png", "Figure 1. Process flow diagram with computed design values (generated by mbr_design.py)"),
);

// 4 Biological design
kids.push(
  H1("4. Biological process design"),
  H2("4.1 Method"),
  P("The minimum sludge age for nitrification is computed at the winter temperature from the net growth rate of the nitrifiers, and a safety factor is applied:"),
  EQ("μA,T = μmax,A·θ^(T−20)·[N/(Kn+N)]·[DO/(Ko+DO)] ;   SRTmin = 1/(μA,T − bA,T)", "1"),
  P("The design aerobic SRT is the larger of 1.5 × SRTmin and 15 d. The effluent biodegradable COD and the biomass production follow the steady-state activated sludge model:"),
  EQ("S = Ks(1 + bH·SRT) / [SRT(μmax,H − bH) − 1]", "2"),
  EQ("PX,bio = Q·YH(S0−S)/(1+bH·SRT) + fd·bH·PX,H·SRT + Q·YA·NOx/(1+bA·SRT)", "3"),
  P("Total solids production adds non-biodegradable VSS, inert inorganic solids and the ferric phosphate and hydroxide sludge. The total biomass inventory is PX,TSS × SRT; the part held in the membrane tanks is subtracted and the remainder sets the bioreactor volume at the design MLSS. The internal recycle ratio and the anoxic volume follow from the nitrate balance:"),
  EQ("IR = NOx/NO3,e − 1 ;   Vanox = (NO3,removed + DO recycled/2.86) / (SDNRT · XVSS)", "4"),
  P("Because the anoxic fraction changes the total SRT, which changes sludge production and the nitrate load, equations 2 to 4 are solved iteratively until the anoxic fraction converges."),
  H2("4.2 Results"),
  TCAP("Table 5. Biological process design results"),
  table(["Quantity", "Value"], [
    ["Minimum nitrification SRT at 12 °C", `${f1(bio.SRT_nit_min)} d`], ["Design aerobic SRT / total SRT", `${f1(bio.SRT_aer)} d / ${f1(bio.SRT_total)} d`],
    ["Anoxic / aerobic / total bioreactor volume", `${f0(bio.V_anox)} / ${f0(bio.V_aer)} / ${f0(bio.V_bio)} m³`],
    ["Anoxic volume fraction", `${f0(bio.f_anox * 100)} %`], ["MLSS bioreactor / membrane tank", `9.0 / ${f2(bio.X_mt)} g/L`],
    ["Hydraulic retention time (incl. membrane tanks)", `${f1(bio.HRT_h)} h`], ["Food-to-microorganism ratio", `${f3(bio.FM)} kg BOD/kg VSS·d`],
    ["Sludge production (incl. chemical sludge)", `${f0(bio.Px_TSS)} kg TSS/d (${f0(bio.chem_sludge)} kg/d chemical)`],
    ["Observed yield", `${f2(bio.Y_obs)} kg TSS/kg BOD`], ["Nitrate formed / removed", `${f1(bio.NOx)} mg N/L / ${f0(bio.NO3_removed)} kg N/d`],
    ["Internal (nitrate) recycle ratio", `${f2(bio.IR)} Q`], ["FeCl₃ demand", `${f0(bio.Fe_kgd)} kg Fe/d`],
    ["Residual alkalinity / supplement", `${f0(bio.alk_eff)} mg CaCO₃/L / ${f0(bio.alk_add_kgd)} kg CaCO₃/d`],
  ], [5000, 4360], { alignLeftFirst: true }),
  P("Residual alkalinity falls below the usual 70–80 mg/L minimum for stable nitrification, mainly because ferric chloride consumes alkalinity, so a small lime, soda ash or magnesium hydroxide dose is included in the design."),
);

// 5 Membrane design
kids.push(
  H1("5. Membrane system design"),
  H2("5.1 Method"),
  P("Flux is corrected for water viscosity at the winter temperature and reduced by the time lost to relaxation and maintenance cleaning:"),
  EQ("JT = J20 · μ20/μT ;   Jnet = JT · tf/(tf + tr) · (1 − fMC)", "5"),
  P("The required area is the largest of three cases: average flow with one train out of service for recovery cleaning, max-month flow at the sustained flux, and peak-hour flow at the short-term peak flux:"),
  EQ("A = max{ Qavg / [Jnet,avg·(N−1)/N] ,  Qmm / Jnet,mm ,  Qph / Jnet,peak }", "6"),
  P("The area is rounded up to whole cassettes per train. Scour air is the installed area multiplied by SAD_m, and the scour air per unit of permeate is SAD_p = SAD_m × 1000 / Jnet."),
  H2("5.2 Results"),
  TCAP("Table 6. Membrane system design results"),
  table(["Quantity", "Value"], [
    ["Viscosity correction at 12 °C / availability", `× ${f3(mem.mu_ratio)} / ${f1(mem.availability * 100)} %`],
    ["Area: average N−1 / max-month / peak-hour", `${f0(mem.A_avg)} / ${f0(mem.A_mm)} / ${f0(mem.A_ph)} m²`],
    ["Governing case", mem.governing], ["Installed", `4 trains × ${mem.n_cas_train} cassettes = ${mem.n_cassettes} cassettes (${f0(mem.n_modules)} modules)`],
    ["Installed membrane area", `${f0(mem.A_installed)} m²`], ["Operating gross flux at average flow", `${f1(mem.J_operating_avg)} L/m²·h`],
    ["Scour air / SAD_p", `${f0(mem.air_scour_Nm3h)} Nm³/h / ${f1(mem.SAD_p)} Nm³/m³`],
    ["Membrane tank volume (all trains) and train size", `${f0(mem.V_mt)} m³; each train ${f1(mem.L_train)} × ${f1(mem.W_train)} × 3.4 m`],
    ["Packing density", `${f0(mem.packing_density)} m²/m³`],
  ], [4300, 5060], { alignLeftFirst: true }),
  P("The operating flux of about 14 L/m²·h and SAD_p of about 20 Nm³/m³ are within the ranges reported for full-scale hollow-fibre MBRs (Judd, 2011)."),
);

// 6 Aeration
const ac = ["winter", "summer", "summer max-day"];
kids.push(
  H1("6. Oxygen demand and aeration"),
  P("The actual oxygen requirement combines carbon oxidation, nitrification and the credit returned by denitrification:"),
  EQ("AOR = Q(S0 − S) − 1.42·PX,bio + 4.57·Q·NOx − 2.86·NO3,removed", "7"),
  P("It is converted to standard (clean-water) conditions with the alpha factor, which falls steeply with MLSS (Krampe & Krauth, 2003), and with mid-depth oxygen saturation corrected for site elevation:"),
  EQ("SOTR = AOR / [ α·F·(β·C*T,H − C)/C*20 · 1.024^(T−20) ] ,   α = exp(−0.08788·MLSS)", "8"),
  P("Coarse-bubble scour air in the membrane tanks also transfers oxygen; this is credited before the fine-bubble process air is sized. Summer max-day governs blower capacity."),
  TCAP("Table 7. Aeration results"),
  table(["Case", "α", "AOR (kg/d)", "Scour O₂ credit (kg/d)", "SOTR (kg/d)", "Process air (Nm³/h)"],
    ac.map((c) => [c, f2(aer[c].alpha), f0(aer[c].AOR), f0(aer[c].AOTR_scour), f0(aer[c].SOTR), f0(aer[c].air_Nm3h)]),
    [1760, 900, 1500, 1900, 1500, 1800]),
  P("The alpha factor of 0.45 at 9 g/L means each kilogram of oxygen needs roughly twice the air it would at CAS concentrations. This is the main energy penalty of operating at high MLSS and is examined further in Sections 11 and 12."),
);

// 7 Energy
const ek = ["process_aeration", "membrane_scour", "permeate_pumping", "RAS_pumping", "MLR_pumping", "anoxic_mixing", "screens_CIP_misc"];
const lab = { process_aeration: "Process aeration", membrane_scour: "Membrane scour air", permeate_pumping: "Permeate pumping",
  RAS_pumping: "RAS pumping", MLR_pumping: "Nitrate recycle pumping", anoxic_mixing: "Anoxic mixing", screens_CIP_misc: "Screens, CIP, miscellaneous" };
kids.push(
  H1("7. Energy demand"),
  P("Blower power uses the adiabatic compression equation (Metcalf & Eddy, 2014) with discharge pressure equal to diffuser submergence plus pipe and diffuser losses; pump power is ρgQH/η."),
  EQ("Pblower = w·R·T1 / (29.7·n·e) · [ (p2/p1)^0.283 − 1 ]", "9"),
  TCAP("Table 8. Average-day energy demand, full scale"),
  table(["Consumer", "Power (kW)", "Specific energy (kWh/m³)"],
    [...ek.map((k) => [lab[k], f0(EF.kW[k]), f3(EF.kWh_m3[k])]), ["TOTAL", f0(Object.values(EF.kW).reduce((a, b) => a + b, 0)), f3(EF.kWh_m3.TOTAL)]],
    [4200, 2400, 2760], { alignLeftFirst: true }),
  P(`The total of ${f2(EF.kWh_m3.TOTAL)} kWh/m³ is typical of a modern MBR. Membrane scour and process aeration together account for about ${f0((EF.kWh_m3.process_aeration + EF.kWh_m3.membrane_scour) / EF.kWh_m3.TOTAL * 100)} %, so they are the main targets for optimisation.`),
);

// 8 Fouling
kids.push(
  H1("8. Membrane fouling and cleaning simulation"),
  P("Membrane performance over 240 days is simulated hour by hour with the resistance-in-series model:"),
  EQ("TMP = μ(T) · J · (Rm + Rres + Rirr + Rperm)", "10"),
  EQ("dRres = k · (J/Jref)² · dV ,   k ∝ (0.25/SADm)^0.8 · (XMT/11.25)^0.5", "11"),
  P("Rm is the clean-membrane resistance. Residual fouling Rres builds with filtered volume and is 75 % removed by weekly maintenance cleans. A fraction becomes irreversible fouling Rirr, which only a recovery clean (CIP) removes; a smaller fraction becomes permanent fouling Rperm. The fouling rate rises with the square of flux (critical-flux behaviour), falls with more scour air and rises with mixed-liquor solids. Flow follows a diurnal pattern with six random storm events, temperature follows the seasons, and one train goes offline during each recovery clean."),
  ...FIG("03_membrane_fouling_TMP.png", "Figure 2. Simulated flux, temperature, TMP and temperature-corrected permeability over 240 days"),
  P("In the reference design, TMP reaches the 0.30 bar trigger once, at day 77 in the cold period when water viscosity is highest, giving roughly 1.5 recovery cleans per year. Permeability drops from about 400 to about 100 L/m²·h·bar between cleans. Both are in line with full-scale experience. The fouling coefficients are calibration constants and should be fitted to pilot data."),
);

// 9 Retrofit
kids.push(
  H1("9. Modernization (retrofit) check"),
  P("The existing plant is assumed to have two aeration tanks of 4,000 m³ operating at 3.5 g/L MLSS, a concentration limited by the solids loading on its two 28 m secondary clarifiers. At the same SRT and nutrient targets, the treatment capacity of a fixed tank volume is proportional to the biomass it can hold:"),
  EQ("Qmax = (Vexisting·XMLSS + VMT·XMT) / (PX,TSS per m³ · SRT)", "12"),
  TCAP("Table 9. Retrofit capacity comparison"),
  table(["Quantity", "Existing CAS", "MBR in same tanks"], [
    ["MLSS", "3.5 g/L", "9.0 g/L (11.25 in membrane tanks)"],
    ["Capacity at SRT 18.4 d with N and P removal", `${f0(rf.Qmax_CAS)} m³/d`, `${f0(rf.Qmax_MBR)} m³/d`],
    ["Capacity gain", "–", `× ${f2(rf.capacity_gain)}`],
    ["Bioreactor volume required for 12,000 m³/d", "–", `${f0(rf.V_mbr_required)} of ${f0(rf.V_existing)} m³ available`],
    ["Secondary clarifiers", "Required", `Released: ${f0(rf.clarifier_volume_released)} m³, ${f0(rf.clarifier_area_released)} m²`],
  ], [3600, 2500, 3260], { alignLeftFirst: true }),
  ...FIG("05_retrofit_capacity.png", "Figure 3. Capacity of the existing tanks as CAS and as MBR, and volume balance"),
  P("The MBR fits within the existing aeration tanks while raising capacity from about 4,500 to 12,000 m³/d with full nitrogen removal. The released clarifiers can house the membrane tanks (about 160 m² footprint), flow equalisation or sludge storage."),
);

// 10 Scale-up
kids.push(
  H1("10. Scale-up technique: pilot to full scale"),
  P("Submerged membranes are scaled by numbering up identical modules rather than by enlarging them. A single pilot module is multiplied into a cassette (×48), a train (×6) and the plant (×4 trains), a total factor of 1,152. Because each module sees the same flux, scour air and mixed liquor, the filtration behaviour measured on the pilot transfers directly, provided the quantities that do change with size are corrected."),
  ...FIG("02_scale_up_strategy.png", "Figure 4. Modular scale-up hierarchy, energy at pilot and full scale, and scale-variant parameters"),
  TCAP("Table 10. Parameters held constant across scales (scale-invariant)"),
  table(["Parameter", "Value", "Why it must be held"], [
    ["Gross flux", `${f1(mem.J_operating_avg)} L/m²·h`, "Fouling rate depends on flux relative to critical flux"],
    ["SAD_m / SAD_p", `0.25 Nm³/m²·h / ${f1(mem.SAD_p)} Nm³/m³`, "Shear at the fibre surface controls cake build-up"],
    ["SRT, MLSS, HRT, F/M", `${f1(bio.SRT_total)} d, 9.0 g/L, ${f1(bio.HRT_h)} h, ${f3(bio.FM)}`, "Sludge properties (EPS, filterability, α) depend on them"],
    ["Recycle ratios R / IR", `4.0 / ${f1(bio.IR)}`, "Solids profile and nitrate removal"],
    ["Filtration/relax cycle, cleaning protocol", "9/1 min; NaOCl, citric acid doses per m²", "Fouling reversibility"],
  ], [2600, 3000, 3760], { alignLeftFirst: true }),
  TCAP("Table 11. Parameters that change with scale and must be corrected (scale-variant)"),
  table(["Parameter", "Pilot", "Full scale", "Consequence"], [
    ["Diffuser submergence", "2.2 m", "5.2 m", "Oxygen transfer efficiency rises with depth"],
    ["Process SOTE", "12.1 %", "28.6 %", "Pilot needs ~2.8× more air per m³"],
    ["Process air", "33.1 Nm³/m³", "11.8 Nm³/m³", "Pilot energy overstates full scale"],
    ["Blower efficiency", "0.45", "0.75", "Small machines are inefficient"],
    ["Mixing power", "15 W/m³", "5 W/m³", "Small tanks need more mixing power"],
    ["Peak-cassette flux factor", "1.00", "1.07", "Uneven suction along long permeate headers"],
    ["Specific energy", `${f2(EP.kWh_m3.TOTAL)} kWh/m³`, `${f2(EF.kWh_m3.TOTAL)} kWh/m³`, "Pilot energy must not be used directly"],
  ], [2300, 1400, 1500, 4160], { alignLeftFirst: true }),
  H2("10.1 Recommended scale-up procedure"),
  NUM("Run the pilot with the full-scale fine screen and the same membrane module, at the design flux, SAD_m, SRT and MLSS, for at least one full winter."),
  NUM("Fit the fouling constants k, firr and the exponents in equation 11 to the measured TMP and permeability, including weekly maintenance cleans."),
  NUM("Measure the alpha factor and oxygen uptake rate at pilot MLSS; use the measured alpha, not the pilot's air consumption, for full-scale blower sizing."),
  NUM("Recalculate oxygen transfer, blower, pump and mixer power for full-scale depths and equipment (Table 11)."),
  NUM("Check permeate manifold head loss so that the most loaded cassette stays within about 5–7 % of the average flux, and add flux margin for that maldistribution."),
  NUM("Check the design against peak-hour flow with all trains and average flow with one train in recovery cleaning (equation 6)."),
);

// 11 Sensitivity
kids.push(
  H1("11. Design sensitivity"),
  ...FIG("04_design_sensitivity.png", "Figure 5. (a) Installed membrane area vs winter temperature and design flux; (b) bioreactor volume and process air vs MLSS"),
  P("Panel (a) shows that a 4 °C colder design temperature adds roughly one cassette per train at any flux, because flux falls with water viscosity; the steps occur where an extra whole cassette is needed. Panel (b) shows the central MBR trade-off: raising MLSS shrinks the bioreactor but the falling alpha factor drives process air up. Between 8 and 12 g/L, the usual MBR operating window, the two effects roughly balance."),
);

// 12 DOE / RSM
const optRows = [["MLSS (g/L)", "9.89", "9.0"], ["Design flux at 20 °C (L/m²·h)", "29.9", "25.0"], ["SAD_m (Nm³/m²·h)", "0.344", "0.25"],
  ["Winter temperature (°C, locked)", "12", "12"], ["Aerobic SRT floor (d)", "12.0", "15.0"]];
const respRows = [["Energy (kWh/m³)", "0.716", "0.704", "0.656"], ["Footprint (m³)", "6,537", "6,312", "8,224"],
  ["Required membrane area (m²)", "30,580", "30,610", "36,600"], ["Mean TMP (bar)", "0.114", "0.115", "0.119"],
  ["Process air, max-day (Nm³/h)", "7,745", "7,689", "7,404"], ["Sludge production (kg TSS/d)", "4,166", "4,193", "4,095"],
  ["Recovery cleans per year", "1.7", "3.0", "1.5"]];
kids.push(
  H1("12. Design of experiments and response-surface optimisation"),
  H2("12.1 Experimental design"),
  P("To optimise several design choices at once, the full model was run over a face-centred central composite design (CCD) in five factors: 32 factorial runs, 10 axial runs and 6 centre points, 48 runs in randomised order. This is the same design JMP builds under DOE › Classical › Response Surface Design. Winter temperature is included as a climate (noise) factor so that its effect is quantified, but it is locked at the 12 °C design value when optimising."),
  TCAP("Table 12. DOE factors and levels"),
  table(["Factor", "Low (−1)", "Centre (0)", "High (+1)"], [
    ["MLSS (g/L)", "7", "9", "11"], ["Design flux at 20 °C (L/m²·h)", "20", "25", "30"], ["SAD_m (Nm³/m²·h)", "0.15", "0.25", "0.35"],
    ["Winter temperature (°C)", "10", "13", "16"], ["Aerobic SRT floor (d)", "12", "16", "20"],
  ], [3960, 1800, 1800, 1800], { alignLeftFirst: true }),
  H2("12.2 Response-surface models"),
  P("A full quadratic model (intercept, 5 linear, 10 two-factor interaction and 5 squared terms) was fitted to each response by least squares, the same model JMP fits with the '& RS' effects in the script of Appendix C."),
  TCAP("Table 13. Goodness of fit of the quadratic models"),
  table(["Response", "R²", "R² adjusted", "RMSE"], [
    ["Energy (kWh/m³)", "0.9980", "0.9964", "0.0066"], ["Footprint (m³)", "0.9996", "0.9992", "63"],
    ["Required membrane area (m²)", "1.0000", "1.0000", "33"], ["Mean TMP (bar)", "0.8957", "0.8184", "0.0067"],
    ["Process air (Nm³/h)", "0.9998", "0.9996", "25"], ["Sludge production (kg/d)", "0.9983", "0.9971", "4.9"],
    ["Recovery cleans per year", "0.9339", "0.8849", "0.84"],
  ], [3960, 1800, 1800, 1800], { alignLeftFirst: true }),
  P("The engineering responses are fitted almost exactly. Mean TMP and the number of recovery cleans fit less well because the cleaning events make them jump in steps; their models are adequate for ranking factors but not for precise prediction."),
  ...FIG("06_doe_scaled_effects.png", "Figure 6. Ten largest scaled effects (coded coefficients) for each optimised response"),
  P("Energy is driven mainly by scour air (SAD_m), then design flux (higher flux means less membrane and so less scour air), then MLSS through the alpha factor. Footprint depends on MLSS and SRT. Mean TMP rises with flux and falls with scour air, so flux and scour air pull energy and fouling in opposite directions."),
  H2("12.3 Desirability optimisation"),
  P("Energy, footprint, membrane area and mean TMP were each converted to a smaller-is-better Derringer desirability between their lowest and highest observed values, and the geometric mean D was maximised over the four controllable factors with temperature locked at 12 °C. The optimum (D = 0.61) was then re-run through the full model to check the prediction."),
  TCAP("Table 14. Optimum factor settings"),
  table(["Factor", "Optimum", "Baseline design"], optRows, [4560, 2400, 2400], { alignLeftFirst: true }),
  TCAP("Table 15. Responses at the optimum: response-surface prediction, full-model check and baseline"),
  table(["Response", "RSM prediction", "Full model", "Baseline"], respRows, [3660, 1900, 1900, 1900], { alignLeftFirst: true }),
  ...FIG("07_rsm_contours.png", "Figure 7. Fitted response surfaces versus MLSS and flux, with the overall desirability (★ = optimum)"),
  ...FIG("08_prediction_profiler.png", "Figure 8. Prediction profiler at the optimum (equivalent of the JMP Profiler)"),
  P("The optimum reduces bioreactor volume by about 23 % and membrane area by about 16 % for about 7 % more energy, trading scour air for a higher, still conservative flux. The full-model check agrees with the RSM prediction within 4 % for every engineering response. Two cautions apply: the optimiser chose the lowest allowed aerobic SRT (12 d), which leaves a small nitrification safety margin in cold weather, so 15 d or more is recommended for the final design; and the recovery-clean frequency at the optimum (about 3 per year) is higher than the model predicts, so it should be confirmed on the pilot."),
);

// 13 JMP
kids.push(
  H1("13. Running the analysis in JMP"),
  P("The response-surface analysis in Section 12 was computed in Python. The same analysis can be reproduced and explored interactively in JMP with the script in Appendix C:"),
  NUM("Place mbr_doe_runs.csv (Appendix D) and MBR_RSM_analysis.jsl in the same folder.", "jmp"),
  NUM("Open MBR_RSM_analysis.jsl in JMP 16 or later and choose Run Script (Ctrl+R).", "jmp"),
  NUM("The script sets factor coding and desirability limits, fits a full quadratic Standard Least Squares model for each of the seven responses and saves the prediction formulas.", "jmp"),
  NUM("It opens the Prediction Profiler with temperature locked at 12 °C and runs Maximize Desirability, then a Contour Profiler with surface plots and a Graph Builder overview.", "jmp"),
  NUM("The optimum and the fit statistics shown in JMP should match Tables 13 to 15.", "jmp"),
  P("The Python model itself can also run inside JMP 18 and later through File › New › Python Script, so the whole workflow can be kept in one tool if preferred."),
);

// 14 Limitations
kids.push(
  H1("14. Limitations and next steps"),
  BUL("Influent data are an illustrative reference case; a site sampling campaign (COD fractionation, TKN, alkalinity, temperature record) is needed."),
  BUL("Steady-state design equations are used; a dynamic simulation (ASM1/ASM2d) should confirm effluent nitrogen under diurnal and storm loads."),
  BUL("Fouling constants are literature-based calibration values and must be fitted to pilot TMP data."),
  BUL("Membrane module dimensions and flux limits are generic; vendor data will change the cassette count and tank layout."),
  BUL("Costs (capital, membrane replacement, chemicals, energy tariffs) are not yet included; adding net present value as a DOE response is a natural extension."),
  new Paragraph({ children: [] }),
  H2("References"),
  P("Judd, S. (2011). The MBR Book: Principles and Applications of Membrane Bioreactors for Water and Wastewater Treatment, 2nd ed. Butterworth-Heinemann, Oxford.", { align: AlignmentType.LEFT }),
  P("Krampe, J., Krauth, K. (2003). Oxygen transfer into activated sludge with high MLSS concentrations. Water Science and Technology 47(11), 297–303.", { align: AlignmentType.LEFT }),
  P("Metcalf & Eddy / AECOM (2014). Wastewater Engineering: Treatment and Resource Recovery, 5th ed. McGraw-Hill, New York.", { align: AlignmentType.LEFT }),
  P("Derringer, G., Suich, R. (1980). Simultaneous optimization of several response variables. Journal of Quality Technology 12(4), 214–219.", { align: AlignmentType.LEFT }),
);

// Appendices
kids.push(H1("Appendix A. mbr_design.py: design model and diagrams"),
  P("Python 3 with numpy and matplotlib. Run with: python mbr_design.py. Outputs are written to the folder mbr_outputs.", { align: AlignmentType.LEFT }),
  ...CODE("mbr_design.py"));
kids.push(H1("Appendix B. doe_runner.py: DOE, response surfaces and JSL generator"),
  P("Requires mbr_design.py in the same folder. Run with: python doe_runner.py.", { align: AlignmentType.LEFT }),
  ...CODE("doe_runner.py"));
kids.push(H1("Appendix C. MBR_RSM_analysis.jsl: JMP analysis script"),
  P("Generated by doe_runner.py. Run in JMP 16 or later together with mbr_doe_runs.csv.", { align: AlignmentType.LEFT }),
  ...CODE(`${OUT}/MBR_RSM_analysis.jsl`));

// Appendix D: DOE table
const dCols = ["Run", "Pattern", "MLSS_gL", "Flux20_LMH", "SADm", "Tmin_C", "SRTaer_d", "Energy_kWh_m3", "Footprint_m3",
  "Membrane_area_req_m2", "Mean_TMP_bar", "RC_per_year"];
const dHdr = ["Run", "Pattern", "MLSS", "Flux", "SAD_m", "T", "SRT", "Energy", "Footprint", "Area", "TMP", "RC/yr"];
const fmtD = (c, v) => {
  const x = Number(v);
  if (["Run", "Pattern"].includes(c)) return v;
  if (["Footprint_m3", "Membrane_area_req_m2"].includes(c)) return f0(x);
  if (["Energy_kWh_m3", "Mean_TMP_bar"].includes(c)) return x.toFixed(3);
  if (c === "RC_per_year") return x.toFixed(1);
  return String(+x.toFixed(2));
};
kids.push(H1("Appendix D. DOE run table (mbr_doe_runs.csv)"),
  P("Units: MLSS g/L; flux L/m²·h at 20 °C; SAD_m Nm³/m²·h; T °C; SRT d; energy kWh/m³; footprint m³; area m²; TMP bar (240-day mean); RC/yr recovery cleans per year. Process air and sludge production columns are in the CSV file. Pattern: 0 = centre point, a/A = axial low/high, −/+ = factorial levels.", { align: AlignmentType.LEFT }),
  table(dHdr, doeRows.map((r) => dCols.map((c) => fmtD(c, r[col(c)]))),
    [520, 880, 700, 700, 700, 560, 600, 820, 960, 960, 760, 700], { size: 15 }));

// ---------------------------------------------------------------- document
const doc = new Document({
  creator: "mbr_design.py", title: "Preliminary Design Analysis of Membrane Bioreactors",
  features: { updateFields: true },
  styles: {
    default: { document: { run: { font: FONT, size: 22 } } },
    paragraphStyles: [
      { id: "Heading1", name: "Heading 1", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 32, bold: true, font: FONT, color: "1F4E79" }, paragraph: { spacing: { before: 120, after: 200 }, outlineLevel: 0 } },
      { id: "Heading2", name: "Heading 2", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 26, bold: true, font: FONT, color: "2E75B6" }, paragraph: { spacing: { before: 240, after: 120 }, outlineLevel: 1 } },
    ],
  },
  numbering: {
    config: ["bullets", "steps", "jmp"].map((ref) => ({
      reference: ref,
      levels: [{ level: 0, format: ref === "bullets" ? LevelFormat.BULLET : LevelFormat.DECIMAL,
                 text: ref === "bullets" ? "•" : "%1.", alignment: AlignmentType.LEFT,
                 style: { paragraph: { indent: { left: 720, hanging: 360 } } } }],
    })),
  },
  sections: [{
    properties: { page: { size: { width: 12240, height: 15840 }, margin: { top: 1440, right: 1440, bottom: 1440, left: 1440 } } },
    headers: { default: new Header({ children: [new Paragraph({ alignment: AlignmentType.RIGHT,
      children: [new TextRun({ text: "MBR modernization: preliminary design analysis", size: 16, color: "808080", font: FONT })] })] }) },
    footers: { default: new Footer({ children: [new Paragraph({ alignment: AlignmentType.CENTER,
      children: [new TextRun({ children: ["Page ", PageNumber.CURRENT, " of ", PageNumber.TOTAL_PAGES], size: 18, color: "808080", font: FONT })] })] }) },
    children: kids,
  }],
});

Packer.toBuffer(doc).then((buf) => {
  fs.writeFileSync(`${OUT}/MBR_Design_Report.docx`, buf);
  console.log("written", buf.length);
});
